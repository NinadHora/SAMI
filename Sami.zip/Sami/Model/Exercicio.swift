//
//  Exercicios.swift
//  Sami
//
//  Created by Ana Da hora on 16/01/19.
//  Copyright © 2019 DaHora. All rights reserved.
//

import Foundation

class Exercicio {
    
    //Mark: Properties
    var nome:String
    var enunciado: String
    
    
    
    
    
    //MARK: Initialization
    
    init (nome:String, enunciado:String){
        
       self.nome = nome
       self.enunciado = enunciado
        
        
    }
    
}
