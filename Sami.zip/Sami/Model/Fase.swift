//
//  Fase.swift
//  Sami
//
//  Created by Ana Da hora on 16/01/19.
//  Copyright © 2019 DaHora. All rights reserved.
//

import Foundation

class Fase {
        
    var titulo:String
    var desafio: String
    var exercicios:[Exercicio]
    var indiceProgresso: Int
    var exercicioAtual:Exercicio {
        return exercicios[indiceProgresso]
    }


    init (titulo:String, desafio:String, exercicios:[Exercicio]) {
        self.titulo = titulo
        self.desafio = desafio
        self.exercicios = exercicios
        self.indiceProgresso = 0
    }
    
    
    
}

