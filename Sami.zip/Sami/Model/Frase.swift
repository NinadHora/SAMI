//
//  Frase.swift
//  Sami
//
//  Created by Ana Da hora on 16/01/19.
//  Copyright © 2019 DaHora. All rights reserved.
//

import Foundation

class Frase : Exercicio{
    
    var respostas : [String] = []
    var gabarito : [String]
    var opcoes : [String]
    var ordem : Int
    

    
    init (nome:String, enunciado:String, gabarito:[String], opcoes:[String], ordem:Int) {

        
        self.gabarito = gabarito
        self.opcoes = opcoes
        self.ordem = ordem
        
    
        
        super.init(nome: nome, enunciado: enunciado)
        
    }
    
    func checkRespostaCorreta()->Bool {
        if gabarito.count != respostas.count {
            return false
        }
    
        for i in 0..<gabarito.count {
            if gabarito[i] != respostas[i] {
                return false
            }
        }
        return true
    }
    
    
    }
    

