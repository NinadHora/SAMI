//
//  Personagem.swift
//  Sami
//
//  Created by Ana Da hora on 16/01/19.
//  Copyright © 2019 DaHora. All rights reserved.
//

import Foundation

class Personagem {
    
    var nome:String
    var imageName: String
    var historia: String
    var fases:[Fase]
    var indiceProgresso: Int
    var faseAtual:Fase {
        return fases[indiceProgresso]
    }

    
    init (nome:String, imageName:String, progresso: Int = 0, historia:String, fases:[Fase]) {
        self.nome = nome
        self.imageName = imageName
        self.indiceProgresso = progresso
        self.historia = historia
        self.fases = fases
        
        
    }
    
    
    func finalizaFase() {
        let ultimoIndice = fases.count-1
        if self.indiceProgresso >= ultimoIndice {
            self.indiceProgresso = ultimoIndice
        } else {
            self.indiceProgresso += 1
        }
    }

}
