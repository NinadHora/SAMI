//
//  Jogo.swift
//  Sami
//
//  Created by Ana Da hora on 16/01/19.
//  Copyright © 2019 DaHora. All rights reserved.
//

import Foundation

var jogo = Jogo.instance
class Jogo {
    static var instance = Jogo()
    var personagens:[Personagem] = []
    var indiceProgresso:Int = 0
    var personagemAtual:Personagem {
        return personagens[indiceProgresso]
    }
    
    
    
    public init(){
        
        
        // Personagem Ada
        // instanciar as frases
        // instanciar os exercicios
        // instanciar fase
        // instanciar personagem
        // adicionar no "personagens"
        
        //Personagens
        
        let exercicio1_1 = Frase(nome: "AdaE1", enunciado: """
Na Inglaterra, se fala inglês.
Ada era inglesa.
Logo, Ada falava
""", gabarito: ["Inglês"], opcoes: ["Inglês", "Espanhol"], ordem: 1)
        
        let exercicio1_2 = Frase(nome: "AdaE2", enunciado: """
            Todo aprendiz tem seus mestres.
            Ada era aprendiz.
            Logo, Ada teve
            """, gabarito: ["Mestres"], opcoes: ["Aprendizes", "Mestres", "Alunos"], ordem: 2)
        let exercicio1_3 = Frase(nome: "AdaE3", enunciado: """
Ada criou o primeiro algoritmo.
Algoritmo é um passo a passo para resolver um problema.
Logo, Ada criou uma forma de resolver
""", gabarito: ["Problemas"], opcoes: ["Passos", "Problemas", "Resoluções", "Formas"], ordem: 3)
        
        let fase1_1 = Fase(titulo: "Ada", desafio: "Ada", exercicios: [exercicio1_1, exercicio1_2, exercicio1_3])
        
        let fase1_2 = Fase(titulo: "Ada", desafio: "Ada", exercicios: [exercicio1_2])
        
        let fase1_3 = Fase(titulo: "Ada", desafio: "Ada", exercicios: [exercicio1_3])
        
        let personagem1 = Personagem(nome: "Ada", imageName: "Ada", historia: "texto", fases: [fase1_1, fase1_2, fase1_3])
        
        personagens.append(personagem1)
        
        // lê os indices e ajusta indiceProgresso no Jogo e no Personagem
        self.loadProgresso()
        
    }
    
    func finalizaPersonagem() {
        let ultimoIndice = personagens.count-1
        if self.indiceProgresso >= ultimoIndice {
            self.indiceProgresso = ultimoIndice
        } else {
            self.indiceProgresso += 1
        }
    }
    
    func saveProgresso() {
        
        let userDefaults = UserDefaults.standard
        
        //Storing
        
        
        userDefaults.set(indiceProgresso, forKey: "indicePersonagem")
        userDefaults.set(personagemAtual.indiceProgresso, forKey: "indiceFase")
        userDefaults.set(personagemAtual.faseAtual.indiceProgresso, forKey: "indiceExercicio")
        
        
        
    }
    
    func loadProgresso(){
        
        let userDefaults = UserDefaults.standard
        
        self.personagens[indiceProgresso] = personagemAtual
        
        indiceProgresso =  userDefaults.integer(forKey: "indicePersonagem")
        personagemAtual.indiceProgresso = userDefaults.integer(forKey: "indiceFase")
        personagemAtual.faseAtual.indiceProgresso = userDefaults.integer(forKey: "indiceExercicio")
        
        
    }
    
    
}

