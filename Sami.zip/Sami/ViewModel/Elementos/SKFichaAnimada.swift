//
//  SKFichaAnimada.swift
//  Sami
//
//  Created by Mariana MOS on 17/01/19.
//  Copyright © 2019 DaHora. All rights reserved.
//

import Foundation
import SpriteKit

class SKFichaAnimada:SKSpriteNode {
    var descerFicha1: [SKTexture]
    var descerFicha2: [SKTexture]
    var descerFicha3: [SKTexture]
    var ficha1Desceu: Bool
    var ficha2Desceu: Bool
    var ficha3Desceu:Bool
    var texturaInicial: SKTexture
    var id: String
    
    
    init(posicao: CGPoint, z: CGFloat) {
        self.id = "FichaAnimada"
        self.descerFicha1 = [SKTexture(imageNamed: "FichaAnimada1"),
                             SKTexture(imageNamed: "FichaAnimada2"),
                             SKTexture(imageNamed: "FichaAnimada3") ]
        self.descerFicha2 = [SKTexture(imageNamed: "FichaAnimada3"),
                             SKTexture(imageNamed: "FichaAnimada4"), SKTexture(imageNamed: "FichaAnimada5")]
        self.descerFicha3 = [SKTexture(imageNamed: "FichaAnimada5"),SKTexture(imageNamed: "FichaAnimada6")]
        
        self.texturaInicial = SKTexture(imageNamed: "FichaAnimada1")
        self.ficha1Desceu = false
        self.ficha2Desceu = false
        self.ficha3Desceu = false
        let tamanho = texturaInicial.size()
        super.init(texture: texturaInicial, color: .clear, size: tamanho)
        
        self.position = posicao
        self.zPosition = z
        self.isUserInteractionEnabled = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func animarFicha1() {
        
        if ficha1Desceu == false {
            let descerFicha1 = SKAction.animate(with: self.descerFicha1, timePerFrame: 0.2)
            self.run(descerFicha1)
            ficha1Desceu = true
            ficha2Desceu = false
            
        }
        
    }
    
    func animarFicha2() {
        if ficha2Desceu == false {
            let descerFicha2 = SKAction.animate(with: self.descerFicha2, timePerFrame: 0.2)
            self.run(descerFicha2)
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.ficha2Desceu = true
            }
        }
    }
    
    func animarFicha3() {
        
        if ficha3Desceu == false {
            let descerFicha3 = SKAction.animate(with: self.descerFicha3, timePerFrame: 0.2)
            self.run(SKAction.sequence([descerFicha3, SKAction.fadeOut(withDuration: 0.2)]))
            ficha3Desceu = true
        }
        
    }
    
}
