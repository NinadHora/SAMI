//
//  SKCaixa.swift
//  Sami
//
//  Created by Ana Da hora on 17/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import SpriteKit

// OK
class SKCaixa:SKSpriteNode {
    
    var manager:ElementosManager
    var id:String
    var textura:SKTexture
    var tamanho:CGSize
    
    init(manager: ElementosManager, posicao: CGPoint, z: CGFloat) {
        
        self.manager = manager
        self.id = "Caixa"
        self.textura = SKTexture(imageNamed: "CaixaIntro5")
        self.tamanho = textura.size()
        super.init(texture: textura, color: .clear, size: tamanho)
        
        self.position = posicao
        self.zPosition = z
        
        self.isUserInteractionEnabled = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        self.manager.tocouEm(id: self.id)
        print("tocou caixa")
    }
    
    func animarCaixa() {
        let rodar1 = SKAction.rotate(toAngle: 0.1, duration: 0.2)
        let rodar2 = SKAction.rotate(toAngle: -0.1, duration: 0.2)
        let rodar3 = SKAction.rotate(toAngle: 0.05, duration: 0.1)
        let rodar4 = SKAction.rotate(toAngle: -0.05, duration: 0.1)
        let voltarInicio = SKAction.rotate(toAngle: 0, duration: 0.1)
        let animar = SKAction.sequence([rodar1, rodar2, rodar3, rodar4, voltarInicio])
        self.run(animar)
    }
    
}
