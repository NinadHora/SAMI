//
//  SKSami.swift
//  Sami
//
//  Created by Ana Da hora on 17/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import SpriteKit

class SKSami: SKSpriteNode {
    
    var manager:ElementosManager
    var id:String
    var textura:SKTexture
    var tamanho:CGSize
    
    // Texturas para animar
    var piscar: [SKTexture]
    var animarAntena: [SKTexture]
    
    // Elementos que se movem
    var antena: SKSpriteNode
    var aurea: SKSpriteNode
    var expressao: SKSpriteNode
    
    var samiAnimado:Bool
    
    init(manager: ElementosManager, posicao: CGPoint, z: CGFloat, nomeTextura: String, samiAnimado: Bool) {
        
        self.manager = manager
        self.id = "Sami"
        self.textura = SKTexture(imageNamed: nomeTextura)
        self.tamanho = textura.size()
        
        self.piscar = [SKTexture(imageNamed: "SamiExpressao1"),
                       SKTexture(imageNamed: "SamiExpressao2"),
                       SKTexture(imageNamed: "SamiExpressao3"),
                       SKTexture(imageNamed: "SamiExpressao2"),
                       SKTexture(imageNamed: "SamiExpressao1")]
        
        self.animarAntena = [SKTexture(imageNamed: "SamiAntena1"),
                             SKTexture(imageNamed: "SamiAntena2"),
                             SKTexture(imageNamed: "SamiAntena3"),
                             SKTexture(imageNamed: "SamiAntena4"),
                             SKTexture(imageNamed: "SamiAntena5")]
        
        self.antena = SKSpriteNode(imageNamed: "SamiAntena1")
        self.aurea = SKSpriteNode(imageNamed: "SamiAurea")
        self.expressao = SKSpriteNode(imageNamed: "SamiExpressao1")
        self.samiAnimado = samiAnimado
        
        super.init(texture: textura, color: .clear, size: tamanho)
        
        configurarElementos()
        self.position = posicao
        self.zPosition = z
        
        self.isUserInteractionEnabled = true
    }
    
    func configurarElementos() {
        
        if samiAnimado == true {
            antena.position = CGPoint(x: 105, y: 275)
            antena.zPosition = 1
            aurea.position = CGPoint(x: -60, y: 0)
            aurea.zPosition = 1
            expressao.position = CGPoint(x: 0, y: 0)
            expressao.zPosition = 1
            
            addChild(antena)
            addChild(aurea)
            addChild(expressao)
            
            girarAurea()
            piscarOlhos()
            balancarAntena()
        }
        
    }
    
    func girarAurea() {
        let girar = SKAction.rotate(byAngle: 0.3, duration: 1)
        aurea.run(SKAction.repeatForever(girar))
    }
    
    func piscarOlhos() {
        let piscar = SKAction.animate(with: self.piscar, timePerFrame: 0.10)
        expressao.run(SKAction.repeatForever(SKAction.sequence([SKAction.wait(forDuration: 0.5), piscar, SKAction.wait(forDuration: 0.4), piscar, SKAction.wait(forDuration: 1.5)])))
    }
    
    func balancarAntena() {
        let animarAntena = SKAction.animate(with: self.animarAntena, timePerFrame: 0.2)
        antena.run(SKAction.repeatForever(animarAntena))
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        manager.tocouEm(id: id)
        print("tocou sami")
        
    }
}

