//
//  SKFundoTelas.swift
//  Sami
//
//  Created by Maria Gorette Soares Tavares on 17/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import Foundation
import SpriteKit

//OK - Mari vai mexer
class SKFundoTelas:SKSpriteNode {
    
    var textura:SKTexture
    var tamanho:CGSize
    
    init(nomeTextura: String) {
        
        self.textura = SKTexture(imageNamed: nomeTextura)
        self.tamanho = textura.size()
        super.init(texture: textura, color: .clear, size: tamanho)
        
        self.position = CGPoint(x: 0, y: 0)
        self.zPosition = -10
        
        self.isUserInteractionEnabled = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

