//
//  SKPorta.swift
//  Sami
//
//  Created by Ana Da hora on 17/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import SpriteKit

// Ok
class SKPorta:SKSpriteNode {
    
    //acessa o protocolo
    var manager: ElementosManager
    
    //textura default
    var textura1: SKTexture
    var id:String
    var tamanho:CGSize
    var nome: String
    
    init(manager: ElementosManager, posicao: CGPoint, z: CGFloat, nomeTextura: String) {
       
        self.nome = nomeTextura
        self.manager = manager
        self.id = "Porta"
        self.textura1 = SKTexture(imageNamed: nomeTextura)
        self.tamanho = textura1.size()
        super.init(texture: textura1, color: .clear, size: tamanho)
        
        self.position = posicao
        self.zPosition = z
        
        
        self.isUserInteractionEnabled = true
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if self.nome == "Porta1Intro2"{
            //muda textura
           proximaTextura()
            //chama função do protocolo - (toca e passa) com delay
           DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                self.manager.tocouEm(id: self.id)
                print("mudou quadro")
            }
        } else if self.nome == "PortaIntro4"{
            //chama função do protocolo - (toca e passa) com delay
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                self.manager.tocouEm(id: self.id)
                print("mudou quadro")
            }
            
        }
        

        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func proximaTextura(){
        //instancia textura 2
        let textura2 = SKTexture(imageNamed: "Porta2Intro2")
        //action muda textura
        let mudaTextura = SKAction.setTexture(textura2)
        run(mudaTextura)
        print("mudou")
    }
    
    
}
