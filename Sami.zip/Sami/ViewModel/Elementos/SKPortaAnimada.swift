//
//  SKPortaAnimada.swift
//  Sami
//
//  Created by Ana Da hora on 17/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import SpriteKit

// Falta Terminar
class SKPortaAnimada:SKSpriteNode {
    
    var manager: ElementosManager
    var abrirPorta: [SKTexture]
    var fecharPorta: [SKTexture]
    var portaAberta: Bool
    var texturaInicial: SKTexture
    var id: String
    
    init(manager: ElementosManager, posicao: CGPoint, z: CGFloat) {
        self.manager = manager
        self.id = "PortaAnimada"
        self.abrirPorta = [SKTexture(imageNamed: "PortaAnimada1"),
                              SKTexture(imageNamed: "PortaAnimada2"),
                              SKTexture(imageNamed: "PortaAnimada3") ]
        self.fecharPorta = [SKTexture(imageNamed: "PortaAnimada3"),
                           SKTexture(imageNamed: "PortaAnimada2"),
                           SKTexture(imageNamed: "PortaAnimada1") ]
        self.texturaInicial = SKTexture(imageNamed: "PortaAnimada1")
        self.portaAberta = false
        let tamanho = texturaInicial.size()
        super.init(texture: texturaInicial, color: .clear, size: tamanho)
    
        self.position = posicao
        self.zPosition = z
        
        self.isUserInteractionEnabled = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        manager.tocouEm(id: id)
        print("tocou porta animada")

    }
    
    func animarPorta() {
        
        if portaAberta == false {
            let abrirPorta = SKAction.animate(with: self.abrirPorta, timePerFrame: 0.2)
            self.run(abrirPorta)
            portaAberta = true
        } else if portaAberta == true {
            let fecharPorta = SKAction.animate(with: self.fecharPorta, timePerFrame: 0.2)
            self.run(fecharPorta)
            portaAberta = false
        }
        
    }
}
