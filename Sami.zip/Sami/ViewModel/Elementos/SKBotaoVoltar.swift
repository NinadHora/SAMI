//
//  SKBotaoVoltar.swift
//  Sami
//
//  Created by Ana Da hora on 17/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//
import SpriteKit

//OK
class SKBotaoVoltar:SKSpriteNode {
    
    var manager:ElementosManager
    var id:String
    var textura:SKTexture
    var tamanho:CGSize
    
    init(manager: ElementosManager, posicao: CGPoint, z: CGFloat) {
        
        self.manager = manager
        self.id = "Voltar"
        self.textura = SKTexture(imageNamed: "BotaoVoltar")
        self.tamanho = textura.size()
        super.init(texture: textura, color: .clear, size: tamanho)
        
        self.position = posicao
        self.zPosition = z
        
        self.isUserInteractionEnabled = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        manager.tocouEm(id: id)
        
    }
}
