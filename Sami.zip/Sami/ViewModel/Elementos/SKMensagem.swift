//
//  SKMensagem.swift
//  Sami
//
//  Created by Mariana MOS on 10/01/19.
//  Copyright © 2019 DaHora. All rights reserved.
//


import SpriteKit


class SKMensagem: SKLabelNode {
    
    
    var texto: String
    var alturaMensagem: CGFloat = 0
    
    init(posicao: CGPoint, texto: String, nomeFonte: String ) {
        //        let attributedString = NSMutableAttributedString(string: texto)
        //        let paragraphStyle = NSMutableParagraphStyle()
        //        paragraphStyle.lineSpacing = 2
        //        attributedString.addAttribute(NSAttributedString.Key.paragraphStyle, value:paragraphStyle, range:NSMakeRange(0, attributedString.length))
        //
        self.texto = texto
        alturaMensagem = 2
        
        super.init(fontNamed: nomeFonte)
        
        //        self.attributedText = attributedString
        self.text = texto
        self.position = posicao
        self.numberOfLines = 5
        self.horizontalAlignmentMode = .left
        self.fontSize = 35
        self.fontName = "American Typewriter"
        self.lineBreakMode = NSLineBreakMode.byWordWrapping
        self.preferredMaxLayoutWidth = 400
        self.zPosition = 12
        self.fontColor = #colorLiteral(red: 0.337254902, green: 0.1960784314, blue: 0.1960784314, alpha: 1)
        alturaMensagem = self.calculateAccumulatedFrame().maxY
        
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //FIXME: entender isso
    override init() {
        texto = ""
        alturaMensagem = 2
        
        super.init()
        
    }
    
}




//convenience init(posicao: CGPoint, texto: String ) {
//
//    let fonte = "American Typewriter"
//    let texto = texto
//    super.init(fontNamed: fonte)
//    self.text = texto
//
//    self.position = posicao
//    self.numberOfLines = 5
//    self.horizontalAlignmentMode = .left
//    self.fontSize = 40
//    self.fontName = "American Typewriter"
//    self.lineBreakMode = NSLineBreakMode.byWordWrapping
//    self.preferredMaxLayoutWidth = 210
//    self.zPosition = 12
//
//}
