//
//  SKQuadro.swift
//  Sami
//
//  Created by Ana Da hora on 17/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import SpriteKit

//OK - Bruna vai mexer

class SKQuadro:SKSpriteNode {
    
    var manager:ElementosManager
    var id:String
    var textura:SKTexture
    var tamanho:CGSize
    var texturaBool: Bool
    
    init(manager: ElementosManager, posicao: CGPoint, z: CGFloat) {
        
        self.manager = manager
        self.id = "Quadro"
        self.textura = SKTexture(imageNamed: "Quadro2")
        self.texturaBool = true
        self.tamanho = textura.size()
        super.init(texture: textura, color: .clear, size: tamanho)
        
        self.position = posicao
        self.zPosition = z
        
        self.isUserInteractionEnabled = true
        
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
      
        if self.texturaBool == true {
            texturaBool = false
            mudarTexturaParaVaso()
            print("mudou vaso")
        } else if self.texturaBool == false {
            texturaBool = true
            mudarTexturaParaFlor()
            print("mudou flor")
        }
        
        print("tocou quadro")
    }
    
    
    func mudarTexturaParaVaso(){
        let texturaVaso = SKTexture(imageNamed: "Quadro1")
        let mudaTexturaParaVaso = SKAction.setTexture(texturaVaso)
        run(mudaTexturaParaVaso)
        }
    
    func mudarTexturaParaFlor(){
        let texturaFlor = SKTexture(imageNamed: "Quadro2")
        let mudaTexturaParaFlor = SKAction.setTexture(texturaFlor)
        run(mudaTexturaParaFlor)
    }
    
    
}

