//
//  SKAdaAnimada.swift
//  Sami
//
//  Created by Mariana MOS on 13/01/19.
//  Copyright © 2019 DaHora. All rights reserved.
//

import Foundation
import SpriteKit

// Falta Terminar
class SKAdaAnimada:SKSpriteNode {
    
    var manager: ElementosManager
    var acordarAda: [SKTexture]
    var piscar: [SKTexture]
    var adaAcordada: Bool
    var texturaInicial: SKTexture
    var id: String
    
    init(manager: ElementosManager, posicao: CGPoint, z: CGFloat) {
        self.manager = manager
        self.id = "AdaAnimada"
        self.acordarAda = [SKTexture(imageNamed: "adaExpressao1"),
                           SKTexture(imageNamed: "adaExpressao2"),
                           SKTexture(imageNamed: "adaExpressao3"),
                           SKTexture(imageNamed: "adaExpressao4"),
                           SKTexture(imageNamed: "adaExpressao5")
                           
        ]
        self.piscar = [SKTexture(imageNamed: "adaExpressao5"),
                            SKTexture(imageNamed: "adaExpressao6"),
                            SKTexture(imageNamed: "adaExpressao7"),SKTexture(imageNamed: "adaExpressao6"),SKTexture(imageNamed: "adaExpressao5") ]
        self.texturaInicial = SKTexture(imageNamed: "adaExpressao1")
        self.adaAcordada = false
        let tamanho = texturaInicial.size()
        super.init(texture: texturaInicial, color: .clear, size: tamanho)
        
        self.position = posicao
        self.zPosition = z
        
        self.isUserInteractionEnabled = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        manager.tocouEm(id: id)
        print("tocou ada")
        
    }
    
    func animarAda() {
        
        if adaAcordada == false {
            
            let acordarAda = SKAction.animate(with: self.acordarAda, timePerFrame: 0.15)
            self.run(acordarAda)
            
            let piscar = SKAction.animate(with: self.piscar, timePerFrame: 0.10)
            print("pisquei")
            self.run(SKAction.repeatForever(SKAction.sequence([SKAction.wait(forDuration: 0.5), piscar, SKAction.wait(forDuration: 0.4), piscar, SKAction.wait(forDuration: 1.5)])))
            
            adaAcordada = true
        }
    }
}
