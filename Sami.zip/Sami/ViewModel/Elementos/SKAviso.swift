//
//  SKAviso.swift
//  Sami
//
//  Created by Maria Gorette Soares Tavares on 14/01/19.
//  Copyright © 2019 DaHora. All rights reserved.
//

import Foundation
import SpriteKit

private class SKAviso: SKSpriteNode {

    init(tamanho: CGSize, texto: String) {
        let texto = SKLabelNode(text: texto)
        let corFundo = #colorLiteral(red: 0.5019607843, green: 0.5019607843, blue: 0.5019607843, alpha: 0.2967412243)
        super.init(texture: nil, color: corFundo, size: tamanho)

        texto.fontSize = 40
        texto.fontName = "Helvetica"
        texto.verticalAlignmentMode = .center
        addChild(texto)

    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}

class SKAvisoCrop: SKNode {
    

    init(tamanho: CGSize, texto: String) {
        let mascara = SKCropNode()
        let preenchimento = SKAviso(tamanho: tamanho, texto: texto)
        super.init()
        
        mascara.addChild(preenchimento)

        let forma = SKShapeNode(rectOf: tamanho, cornerRadius: 20)
        forma.fillColor = UIColor.white
        mascara.maskNode = forma
        mascara.maskNode?.position = CGPoint(x: self.position.x, y: self.position.y)
        mascara.maskNode?.zPosition = 0.1
        self.addChild(mascara)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
