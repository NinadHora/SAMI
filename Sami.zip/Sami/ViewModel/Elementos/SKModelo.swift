//
//  SKModelo.swift
//  Sami
//
//  Created by Maria Gorette Soares Tavares on 20/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import Foundation
import SpriteKit

//OK
class SKModelo:SKSpriteNode {

    
    var manager:ElementosManager
    var id:String
    var textura:SKTexture
    var tamanho:CGSize
    
    init(manager: ElementosManager, nomeTextura: String, id: String, posicao: CGPoint, z: CGFloat) {
        
        self.manager = manager
        self.textura = SKTexture(imageNamed: nomeTextura)
        self.id = id
        self.tamanho = textura.size()
        super.init(texture: textura, color: .clear, size: tamanho)
        
        self.position = posicao
        self.zPosition = z
            
        self.isUserInteractionEnabled = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        manager.tocouEm(id: id)
        print("tocou", id)
        
    }
}
