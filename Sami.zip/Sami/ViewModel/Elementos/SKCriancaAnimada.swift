//
//  SKCriancaAnimada.swift
//  Sami
//
//  Created by Maria Gorette Soares Tavares on 17/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import Foundation
import SpriteKit

//OK - Bruna vai mexer

class SKCriancaAnimada:SKSpriteNode, Parallaxable {
   
    var parallaxFactor: CGFloat = 0.3
    
    var manager:ElementosManager
    var id:String
    var textura:SKTexture
    var tamanho:CGSize
 //   var status: String
    
    init(manager: ElementosManager, posicao: CGPoint, z: CGFloat) {
        
        self.manager = manager
        self.id = "CriancaAnimada"
        self.textura = SKTexture(imageNamed: "MeninaAnimada1")
        self.tamanho = textura.size()
        super.init(texture: textura, color: .clear, size: tamanho)
        self.position = posicao
        self.zPosition = z
        
        // tem que ter essa linha, senão não detecta o toque
        self.isUserInteractionEnabled = true
 
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func mudouTextura(){
            let textura2 = SKTexture(imageNamed: "MeninaAnimada2")
            let mudouTextura = SKAction.setTexture(textura2)
            run(mudouTextura)
            print("mudou")
    }
}
