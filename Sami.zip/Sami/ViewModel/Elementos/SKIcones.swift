//
//  SKIcones.swift
//  Sami
//
//  Created by Ana Da hora on 17/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import SpriteKit

//OK - Mari vai mexer
class SKIcone:SKSpriteNode {
    
    var manager:ElementosManager
    var id:String
    var textura:SKTexture
    var tamanho:CGSize
    
    init(manager: ElementosManager, posicao: CGPoint, nomeTextura: String, id: String) {
        
        self.manager = manager
        self.id = id
        self.textura = SKTexture(imageNamed: nomeTextura)
        self.tamanho = textura.size()
        super.init(texture: textura, color: .clear, size: tamanho)
        
        self.position = posicao
        self.zPosition = 10
        
        self.isUserInteractionEnabled = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        manager.tocouEm(id: id)
        print("tocou em:", id)
    }
}
