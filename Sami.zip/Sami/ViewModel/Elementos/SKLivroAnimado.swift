//
//  SKLivroAnimado.swift
//  Sami
//
//  Created by Mariana MOS on 09/01/19.
//  Copyright © 2019 DaHora. All rights reserved.
//

import Foundation
import SpriteKit

// Falta Terminar
class SKLivroAnimado:SKSpriteNode {
    
    var manager: ElementosManager
    var abrirLivro: [SKTexture]
    var fecharLivro: [SKTexture]
    var passarPagina: [SKTexture]
    var passarPagina2: [SKTexture]
    var voltarPagina: [SKTexture]
    var livroAberto: Bool
    var paginaPassada: Bool
    var texturaInicial: SKTexture
    var id: String
    var adaAnimada: SKAdaAnimada!

    
    init(manager: ElementosManager, posicao: CGPoint, z: CGFloat) {
        self.manager = manager
        self.id = "LivroAnimado"
        self.adaAnimada =  SKAdaAnimada(manager: manager, posicao: CGPoint(x: -300, y: 60), z: 14)
        self.abrirLivro = [SKTexture(imageNamed: "LivroAnimado1"),
                           SKTexture(imageNamed: "LivroAnimado2"),
                           SKTexture(imageNamed: "LivroAnimado3") ]
        self.fecharLivro = [SKTexture(imageNamed: "LivroAnimado3"),
                            SKTexture(imageNamed: "LivroAnimado2"),
                            SKTexture(imageNamed: "LivroAnimado1") ]
        self.passarPagina = [SKTexture(imageNamed: "LivroAnimado4"),SKTexture(imageNamed: "LivroAnimado5"),SKTexture(imageNamed: "LivroAnimado6")]
        
        self.voltarPagina = [SKTexture(imageNamed: "LivroAnimado5"),SKTexture(imageNamed: "LivroAnimado4"),SKTexture(imageNamed: "LivroAnimado3")]
        self.passarPagina2 = [SKTexture(imageNamed: "LivroAnimado4"), SKTexture(imageNamed: "LivroAnimado5")]
        self.texturaInicial = SKTexture(imageNamed: "LivroAnimado1")
        self.livroAberto = false
        self.paginaPassada = false
        let tamanho = texturaInicial.size()
        super.init(texture: texturaInicial, color: .clear, size: tamanho)
        
        self.position = posicao
        self.zPosition = z
        self.adaAnimada.isHidden = true
        self.addChild(adaAnimada)
        self.isUserInteractionEnabled = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        manager.tocouEm(id: id)
        print("tocou livro animado")
        
    }
    
    func animarLivro() {
        
        if livroAberto == false {
            let abrirLivro = SKAction.animate(with: self.abrirLivro, timePerFrame: 0.2)
            self.run(abrirLivro)
            livroAberto = true
            paginaPassada = false
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
                self.adaAnimada.isHidden = false
                self.adaAnimada.animarAda()
            }
            
        } 
        
    }
    
    func passarPaginaDoLivro() {
        if paginaPassada == false {
            adaAnimada.isHidden = true
            let passarPagina = SKAction.animate(with: self.passarPagina, timePerFrame: 0.2)
            self.run(passarPagina)

            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.adaAnimada.isHidden = false
                self.paginaPassada = true
            }
    
        }
    }
    
    func voltarPaginaDoLivro() {
        
        adaAnimada.isHidden = true
        if paginaPassada == true {
            let voltarPagina = SKAction.animate(with: self.voltarPagina, timePerFrame: 0.2)
            self.run(voltarPagina)
            paginaPassada = false
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.adaAnimada.isHidden = false

            }
        }
        
    }
    func passarPaginaDoLivro2() {
        
            adaAnimada.isHidden = true
            let passarPagina2 = SKAction.animate(with: self.passarPagina2, timePerFrame: 0.2)
            self.run(passarPagina2)
       
    }
    
}



