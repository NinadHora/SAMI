//
//  SKMeninoAnimado.swift
//  Sami
//
//  Created by Ana Da hora on 17/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import Foundation
import SpriteKit


class SKMeninoAnimado:SKSpriteNode, Parallaxable {
    
    var parallaxFactor: CGFloat = 0.12
    
    var manager:ElementosManager
    var id:String
    var textura:SKTexture
    var tamanho:CGSize
  
    var animar: [SKTexture]
    var animar2: [SKTexture]
    var animar3: [SKTexture]
    
    init(manager: ElementosManager, posicao: CGPoint, z: CGFloat, nomeTextura: String) {
    
        self.manager = manager
        self.id = "MeninoAnimado"
        
        self.textura  = SKTexture(imageNamed: nomeTextura)
        
        self.animar = [SKTexture(imageNamed: "MeninoAnimado1.1"),
                       SKTexture(imageNamed: "MeninoAnimado1.2")]
        self.animar2 = [SKTexture(imageNamed: "MeninoAnimado2.1"),
                       SKTexture(imageNamed: "MeninoAnimado2.2")]
        self.animar3 = [SKTexture(imageNamed: "MeninoAnimado3.1"),
                        SKTexture(imageNamed: "MeninoAnimado3.2")]
        

        self.tamanho = textura.size()
        super.init(texture: textura, color: .clear, size: tamanho)
        self.position = posicao
        self.zPosition = z
        // tem que ter essa linha, senão não detecta o toque
        self.isUserInteractionEnabled = true
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
}

    
    func animarMenino1(){
        let animarMenino = SKAction.animate(with: self.animar, timePerFrame: 0.5)
        self.run(SKAction.repeatForever(animarMenino))
    }
    
    func animarMenino2(){
        let animarMenino2 = SKAction.animate(with: self.animar2, timePerFrame: 0.5)
        let wait = SKAction.wait(forDuration: 2)
        let sequencia = SKAction.sequence([wait, animarMenino2])
        run(sequencia)
    }
    
    func animarMenino3(){
        let animarMenino3 = SKAction.animate(with: self.animar3, timePerFrame: 0.5)
        self.run(SKAction.repeatForever(animarMenino3))
    }
}
