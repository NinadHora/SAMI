//
//  SKEnunciado.swift
//  Sami
//
//  Created by Mariana MOS on 21/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import Foundation
import SpriteKit

class SKEnunciado: SKLabelNode {
    
    
    var texto: String
    
    init(posicao: CGPoint, texto: String, nomeFonte: String ) {
        
        self.texto = texto
        
        super.init(fontNamed: nomeFonte)
        
        //        self.attributedText = attributedString
        self.text = texto
        self.position = posicao
        self.numberOfLines = 5
        self.horizontalAlignmentMode = .left
        self.fontSize = 30
        self.fontName = "American TypeWriter"
        self.lineBreakMode = NSLineBreakMode.byWordWrapping
        self.preferredMaxLayoutWidth = 350
        self.zPosition = 12
        self.fontColor = #colorLiteral(red: 0.337254902, green: 0.1960784314, blue: 0.1960784314, alpha: 1)
        
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //FIXME: entender isso
    override init() {
        texto = ""
        super.init()
        
    }
    
}
