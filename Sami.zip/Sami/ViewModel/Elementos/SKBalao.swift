//
//  SKBalao.swift
//  Sami
//
//  Created by Ana Da hora on 17/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import SpriteKit

//OK
class SKBalao:SKSpriteNode {
    
    var manager: ElementosManager
    var id:String
    var textura:SKTexture
    var tamanho:CGSize
    var nome: String
    var texto: SKLabelNode
    
    
    
    init(manager: ElementosManager, posicao: CGPoint, z: CGFloat, nomeTextura: String, texto: String, id: String) {
        self.texto = SKLabelNode(text: texto)
        nome = nomeTextura
        self.manager = manager
        nome = nomeTextura
        self.id = id
        self.textura = SKTexture(imageNamed: nomeTextura)
        self.tamanho = textura.size()
        super.init(texture: textura, color: .clear, size: tamanho)
        
        let comprimento = self.size.width
        
        self.texto.numberOfLines = 4
        self.texto.position = CGPoint(x: -20, y: 0)
        self.texto.horizontalAlignmentMode = .center
        self.texto.verticalAlignmentMode = .center
        self.texto.fontSize = 28
        //        self.texto.fontName = "Helvetica"
        self.texto.fontName = "IstokWeb-Bold"
        self.texto.fontColor = #colorLiteral(red: 0.3574119607, green: 0.3574119607, blue: 0.3574119607, alpha: 1)
        self.texto.lineBreakMode = NSLineBreakMode.byWordWrapping
        self.texto.zPosition = 15
        self.texto.preferredMaxLayoutWidth = (comprimento - 100)
        addChild(self.texto)
        
        self.position = posicao
        self.zPosition = z
        
        self.isUserInteractionEnabled = true

    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        self.manager.tocouEm(id: id)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func animarBalao() {
        let aumentaBalao = SKAction.scale(to: 1.1, duration: 0.2)
        let diminuiBalao = SKAction.scale(to: 0.9, duration: 0.2)
        let pararBalao = SKAction.scale(to: 1.0, duration: 0.2)
        let animar = SKAction.sequence([aumentaBalao, diminuiBalao, pararBalao])
        self.run(animar)
    }
    
}

