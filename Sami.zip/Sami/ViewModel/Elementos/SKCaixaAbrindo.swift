//
//  SKCaixaAbrindo.swift
//  Sami
//
//  Created by Maria Gorette Soares Tavares on 17/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import Foundation
import SpriteKit

//OK - Bruna vai mexer

class SKCaixaAbrindo:SKSpriteNode {
    
    var manager:ElementosManager
    var id:String
    var textura:SKTexture
    var tamanho:CGSize
    var nome: String
    
    var contagem:Int = 0
    
    init(manager: ElementosManager, posicao: CGPoint, z: CGFloat, nomeTextura: String) {
        self.nome = nomeTextura
        self.manager = manager
        self.id = "CaixaAbrindo"
        self.textura = SKTexture(imageNamed: nomeTextura)
        self.tamanho = textura.size()
        super.init(texture: textura, color: .clear, size: tamanho)
        self.position = posicao
        self.zPosition = z
        
        // tem que ter essa linha, senão não detecta o toque
        self.isUserInteractionEnabled = true
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let touch = touches.first!
        let location = touch.location(in: self)
        if contagem < 6 {
            ativarParticular(posicao: location)
        }
        contagem += 1
        
        switch contagem {
        case 3:
            if self.nome == "CaixaAnimada1"{
                let textura2 = SKTexture(imageNamed: "CaixaAnimada2")
                let mudaTextura = SKAction.setTexture(textura2)
                run(mudaTextura)
                print("textura1", self.nome)
                self.nome = "CaixaAnimada2"
            }
        case 5:
            if self.nome == "CaixaAnimada2"{
                let textura3 = SKTexture(imageNamed: "CaixaAnimada3")
                //action muda textura
                let mudaTextura2 = SKAction.setTexture(textura3)
                run(mudaTextura2)
                print("textura2", self.nome)
                self.nome = "CaixaAnimada3"
            }
        case 6:
            if self.nome == "CaixaAnimada3"{
                manager.tocouEm(id: "CaixaAnimada3")
                print("textura3", id)
            }
        default:
            print("nada")
        }
        
    }
    
    func ativarParticular(posicao: CGPoint) {
        let papelParticula = Bundle.main.path(forResource: "papelParticula", ofType: "sks")
        let particula = NSKeyedUnarchiver.unarchiveObject(withFile: papelParticula!) as! SKEmitterNode
        particula.numParticlesToEmit = 6
        particula.particleScale = 0.8
        particula.position = posicao
        self.addChild(particula)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

