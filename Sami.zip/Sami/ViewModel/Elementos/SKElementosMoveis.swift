//
//  SKElementosMoveis.swift
//  Sami
//
//  Created by Ana Da hora on 17/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import SpriteKit

//OK
class SKElementosMoveis:SKSpriteNode {
    
    var jogo = Jogo.instance
    var contador: Int
    var textura:SKTexture
    var tamanho:CGSize
    var texto:SKLabelNode
    var posicaoInicial: CGPoint
    init(posicao: CGPoint, z: CGFloat, texto: String) {
        self.contador = 0
        self.posicaoInicial = posicao
        self.texto = SKLabelNode(text: texto)
        self.textura = SKTexture(imageNamed: "0ElementoMovel")
        self.tamanho = textura.size()
        super.init(texture: textura, color: .clear, size: tamanho)
        
        self.position = posicao
        self.zPosition = z
        
        let comprimento = self.size.width
        self.texto.numberOfLines = 4
        self.texto.position = CGPoint(x: 0, y: 0)
        self.texto.horizontalAlignmentMode = .center
        self.texto.verticalAlignmentMode = .center
        self.texto.fontSize = 24
        self.texto.fontName = "Helvetica"
        self.texto.fontColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        self.texto.lineBreakMode = NSLineBreakMode.byWordWrapping
        self.texto.zPosition = 15
        self.texto.preferredMaxLayoutWidth = (comprimento - 20)
        addChild(self.texto)
        
        self.isUserInteractionEnabled = true
        
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        let location = touch!.location(in: self)
        let move = SKAction.move(to: self.position+location, duration: 0)
        self.run(move)
        
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let exercicioFrase = jogo.personagemAtual.faseAtual.exercicioAtual as! Frase
        let touch = touches.first
        let location = touch!.location(in: self)
        let positionlocation = position+location
        if positionlocation.x <= 600 && positionlocation.x >= 300 && positionlocation.y <= 50 && positionlocation.y >= -50{
            
            self.position = CGPoint(x: 450, y: 0)
            exercicioFrase.respostas.append(texto.text!)
            print(exercicioFrase.respostas)
        }else {
            self.position = self.posicaoInicial
        }
    }
    
    
}

