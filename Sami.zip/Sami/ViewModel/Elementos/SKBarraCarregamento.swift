//
//  SKBarraCarregamento.swift
//  Sami
//
//  Created by Maria Gorette Soares Tavares on 08/01/19.
//  Copyright © 2019 DaHora. All rights reserved.
//

import Foundation
import SpriteKit

class SKBarraCarregamento: SKNode  {
    
    var barraCarregamento : SKCropNode
    init(imagemPreenchimento : String) {
        barraCarregamento = SKCropNode()
        super.init()
        let preenchimento  = SKSpriteNode(imageNamed: imagemPreenchimento)
        barraCarregamento.addChild(preenchimento)
        barraCarregamento.maskNode = SKSpriteNode(color: UIColor.white,
                                                  size: CGSize(width: 1334, height: 100 ))
        barraCarregamento.maskNode?.position = CGPoint(x: self.position.x,
                                                       y: -preenchimento.size.height/2)
        barraCarregamento.zPosition = 0.1
        self.addChild(barraCarregamento)
    }
    
    func alterarProgressoY(valor : CGFloat){
        barraCarregamento.maskNode?.yScale = valor
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
