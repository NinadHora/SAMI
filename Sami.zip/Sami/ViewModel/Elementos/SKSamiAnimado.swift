//
//  SKSamiAnimado.swift
//  Sami
//
//  Created by Ana Da hora on 17/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import SpriteKit

class SKSamiAnimado: SKSpriteNode {
    
    var manager:ElementosManager
    var id:String
    var textura:SKTexture
    var tamanho:CGSize
    var acordar: [SKTexture]
    
    init(manager: ElementosManager, posicao: CGPoint, z: CGFloat) {
        
        self.manager = manager
        self.id = "SamiAnimado"
        self.textura = SKTexture(imageNamed: "SamiAnimado1")
        self.tamanho = textura.size()
        self.acordar = [SKTexture(imageNamed: "SamiAnimado1"),
                                 SKTexture(imageNamed: "SamiAnimado2"),
                                 SKTexture(imageNamed: "SamiAnimado3"),
                                 SKTexture(imageNamed: "SamiAnimado4"),
                                 SKTexture(imageNamed: "SamiAnimado5"),
                                 SKTexture(imageNamed: "SamiAnimado6"),
                                 SKTexture(imageNamed: "SamiAnimado7"),
                                 SKTexture(imageNamed: "SamiAnimado8"),
                                 SKTexture(imageNamed: "SamiAnimado9"),
                                 SKTexture(imageNamed: "SamiAnimado10")]
        super.init(texture: textura, color: .clear, size: tamanho)
        
        self.position = posicao
        self.zPosition = z
        self.isUserInteractionEnabled = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        manager.tocouEm(id: id)
        print("tocou Sami")
        
    }
    
    func acordaSami() {
        let animar = SKAction.animate(with: acordar, timePerFrame: 0.1)
        self.run(animar)
    }
}

