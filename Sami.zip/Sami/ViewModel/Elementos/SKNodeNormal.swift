//
//  SKNodeNormal.swift
//  Sami
//
//  Created by Bruna Tardioli on 21/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import Foundation
import SpriteKit

//OK
class SKNodeNormal:SKSpriteNode, Parallaxable {
    
    var parallaxFactor: CGFloat

    var textura:SKTexture
    var tamanho:CGSize
    
    init(nomeTextura: String, posicao: CGPoint, z: CGFloat, itemParallaxFactor: CGFloat = 0.0) {
        
        self.parallaxFactor = itemParallaxFactor
        
        self.textura = SKTexture(imageNamed: nomeTextura)
        self.tamanho = textura.size()
        super.init(texture: textura, color: .clear, size: tamanho)
        
        self.position = posicao
        self.zPosition = z
        
        self.isUserInteractionEnabled = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
