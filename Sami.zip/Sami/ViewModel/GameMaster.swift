//
//  GameMaster.swift
//  Sami
//
//  Created by Ana Da hora on 30/11/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import Foundation
import SpriteKit
import GameplayKit

class GameMaster {
   
    // Ordem dos personagens
    
    /** var personagensArray :[SKSpriteNode] = [SKSpriteNode] ()
     let vetores : SKSpriteNode!
     let dad = SKSpriteNode(imageNamed: "dad0")
     var imageName = "dad"
     
     let moveLeft = SKAction.moveByX(-10, y:0 , duration: 0.01)
     
     func order () {
     if index == 0{
     index += 1 //image names are dad0, dad1
     imageName += "\(index)"
     print(imageName)
     dad.texture = SKTexture(imageNamed:imageName)
     }
     else{
     index += 1
     imageName += "\(index)"
     print(imageName)
     dad.texture = SKTexture(imageNamed:imageName)
     //moves dad
     dad.runAction(moveLeft) // moves image
     index = 0
     }
     //change the image name back to dad
     imageName = "dad"
     
     
     }
 
 
 **/
    
/**
     Colocará as personagens na ordem certa, isso irá influenciar a ordem do storybook.
     
     Precisará acessar lista de personagens, está estará ligada a interaçao dos quadrinhos ou seja, os quadrinhos irão passar de acordo com esta lista.
     
     Por exemplo no momento temos so a Ada Lovelace entao o Game master nao fará muito sentido nesta primeira parte.
     
     lista de todos os  personagens e uma lista com todos os quadrinhos do storybook . fazer uma comparação entre lista de personagem  e lista de quadrinhos, para saber se o personagem está sendo colocado no quadrinho correto.
 **/
    
    
    
    
    
    
    
    
}
