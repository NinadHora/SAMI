//
//  MoverCapitulos.swift
//  Sami
//
//  Created by Ana Da hora on 30/11/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import Foundation
import SpriteKit
import GameplayKit

class MoverExercicio {
    
    
    /** esta classe irá mover os exercicios e não as fases por exemplo na fase da Ada tem 3 exercicios esta classe irá aplicar a lógica para que a personagem tenha progresso de acordo com o resultado do exercicio , então estará ligado com o progresso da personagem. Mas não usará todas as propriedades da classe do progressoPersonagem. então teremos que ter acesso publico entre as classes.
    
    **/
    
    
    
}
