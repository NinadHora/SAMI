//
//  Extension.swift
//  Sami
//
//  Created by Bruna Tardioli on 15/01/19.
//  Copyright © 2019 DaHora. All rights reserved.
//

import SpriteKit


extension CGPoint {
    static func +(left:CGPoint, right: CGPoint)->CGPoint {
        return (CGPoint(x: left.x+right.x,
                        y: left.y+right.y))
    }
    
    static func *(lhs:CGPoint, rhs: CGFloat)->CGPoint {
        return (CGPoint(x: lhs.x*rhs, y: lhs.y*rhs))
    }
    
//    static func /(lhs:CGPoint, rhs: CGPoint)->CGPoint {
//        return (CGPoint(x: lhs.x/rhs.x==0 ? 1: rhs.x , y: lhs.y/rhs.y==0 ? 1: rhs.y))
//    }
    
    func isBigger(than other: CGPoint)->Bool {
        return self.x != other.x ? self.x > other.x : self.y > other.y
    }
    
    var modulo:CGPoint {
        return CGPoint(x: CGFloat(abs(Double(self.x))), y: CGFloat(abs(Double(self.y))))
    }
    
    var sinal:CGPoint {
        return CGPoint(x: self.x < 0 ? -1 : 1, y: self.y < 0 ? -1 : 1)
    }
    

    mutating func limitMod(_ limit: CGPoint) {
        let sinal = self.sinal
        let modulo = self.modulo
        print(sinal, modulo)

        if modulo.x > limit.x {
            self.x = limit.x * sinal.x
        }
        
        if modulo.y > limit.y {
            self.y = limit.y * sinal.y
        }
    }
        
}
