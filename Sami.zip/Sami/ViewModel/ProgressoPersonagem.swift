//
//  ProgressoPersonagem.swift
//  Sami
//
//  Created by Ana Da hora on 30/11/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import Foundation
import SpriteKit
import GameplayKit

class ProgressoPersonagem {
    
/**  a personagem menina percorre todo o livro e faz os exercícios - guardar este progresso do personagem. Usar um booleano para indicar quando ela tiver completado e quando ela nao tiver completado : 0 ou 1 .
 Se ela tiver completado o exercício avançar fase. Se ela não tiver completado subir pop up indicando que falta completar .
 Se ela tiver completado todos os exercicios e quiser somente ver o sotybook novamente. Com o progresso salvo ela não precisará refazer os exercícios.
     Caso o progresso seja interrompido, salvar o momento que for interrompido e a historia irá continuar a partir deeste momento. (Progresso de fase e Progresso de personagem salvos juntos)
     A cada progresso da personagem  total nos exercicios pois existem casos que a personagem tea que completar mais de um exercicio pra passar de fase será liberado uma fase - será que isso precisa entrar na mesma lógica da personagem? 
     
 
 **/
 

    
    
    
    
    
}
