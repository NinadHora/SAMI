//
//  StatusFase.swift
//  Sami
//
//  Created by Ana Da hora on 26/11/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import Foundation
import SpriteKit
import GameplayKit


class ProgressoFase



{
    
/** o progresso da fase está ligado ao progresso total da personagem nos exercicios. A personagem passou pelos exercicios da Ada Lovelace então ela passou de fase.
     Tem a fase dentro da Ada que sao os exercicios, 3 exercicios da Ada lovelace, quando passar de um exercicio para a outra classe que é progresso da personagem e nao progresso da fase, está ligado a função mais geral
 
 **/
    
}
