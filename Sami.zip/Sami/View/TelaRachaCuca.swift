//
//  TelaRachaCuca.swift
//  Sami
//
//  Created by Ana Da hora on 30/11/18.
//  Copyright © 2018 DaHora. All rights reserved.
//
//Herdando de elemento
// bruna e gorette
import Foundation
import SpriteKit

class TelaRachaCuca:SKScene {
    
    
    override func didMove(to view: SKView) {
        
        
    }
}
