//
//  TelaAdaConclusao.swift
//  Sami
//
//  Created by Mariana MOS on 16/01/19.
//  Copyright © 2019 DaHora. All rights reserved.
//

import Foundation
import SpriteKit

class TelaAdaConclusao:SKScene{
    
    var iconeVoltar: SKBotaoVoltar!
    var fundo: SKFundoTelas!
    var medalha: SKIcone!
    var manager: ElementosManager!
    
    override func didMove(to view: SKView) {
        
        criarElementos()
        
    }
    
    func criarElementos() {
        fundo = SKFundoTelas(nomeTextura: "BackTelaConclusao")
        addChild(fundo)
        medalha = SKIcone(manager: self, posicao: CGPoint(x: 300, y: 50), nomeTextura: "Medalha", id: "Medalha")
        addChild(medalha)
        iconeVoltar = SKBotaoVoltar(manager: self, posicao: CGPoint(x: -580, y: 300), z: 10)
        addChild(iconeVoltar)
        
    }
}

extension TelaAdaConclusao: ElementosManager {
    
    func tocouEm(id: String) {
        
        switch id {
            
        case "Medalha":
            medalha.isHidden = true
            ativarParticula(posicao: medalha.position)
            
            
        case "Voltar":
            if let novaCena = Biblioteca(fileNamed: "Biblioteca"){
                novaCena.scaleMode = .aspectFill
                //                let transition = SKTransition.moveIn(with: .up, duration: 0.3)
                self.view?.presentScene(novaCena)
            }
            
        default:
            break
        }
        
    }
    func ativarParticula(posicao: CGPoint) {
        let confetesParticula = Bundle.main.path(forResource: "Confetes", ofType: "sks")
        let particula = NSKeyedUnarchiver.unarchiveObject(withFile: confetesParticula!) as! SKEmitterNode
        
        particula.numParticlesToEmit = 60
        particula.position = posicao
        self.addChild(particula)
    }
    
}

