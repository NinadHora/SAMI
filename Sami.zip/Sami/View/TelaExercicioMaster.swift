//
//  TelaExercicioMaster.swift
//  Sami
//
//  Created by Mariana MOS on 19/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import Foundation
import SpriteKit

class TelaExercicioMaster : SKScene {
    var fundo: SKFundoTelas!
    var iconeVoltar: SKBotaoVoltar!
    var iconeSami: SKIcone!
    
    override func didMove(to view: SKView) {
        criarElementos()
    }
    
    func criarElementos () {
        fundo = SKFundoTelas(nomeTextura: "BackExercicioAda")
        addChild(fundo)
        iconeVoltar = SKBotaoVoltar(manager: self, posicao: CGPoint(x: -580, y: 300), z: 10)
        addChild(iconeVoltar)
        
        
        
    }
}

@objc extension TelaExercicioMaster: ElementosManager {
    func tocouEm(id: String) {
        switch id {
        case "Voltar":
            if let novaCena = Biblioteca(fileNamed: "Biblioteca"){
                novaCena.scaleMode = .aspectFill
                //                let transition = SKTransition.moveIn(with: .up, duration: 0.3)
                self.view?.presentScene(novaCena)
            }
            
        default:
            print("nao tocou")
        }
    }
}
