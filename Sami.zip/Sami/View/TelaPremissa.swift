//
//  TelaPremissa.swift
//  Sami
//
//  Created by Ana Da hora on 30/11/18.
//  Copyright © 2018 DaHora. All rights reserved.
//
// Herdando de elemento
// mari e gorette

import Foundation
import SpriteKit

class TelaPremissa: TelaExercicioMaster {
    
    var iconeAvancarPagina: SKIcone!
    var exercicio: Personagem!
    var opcao1e3x: Int! = 200
    var opcao2e4x: Int! = 400
    var opcao1e2y: Int! = -120
    var opcao3e4y: Int! = -220
    var posicoesElementosMoveis: [CGPoint]!
    var frase: Frase!
    var jogo = Jogo.instance
    var explicacao: SKMensagem!
    var estrela1: SKNodeNormal!
    var estrela2: SKNodeNormal!
    var estrela3: SKNodeNormal!
    var enunciado: SKEnunciado!
    var elementosMoveis: [SKElementosMoveis] = []
    var gabarito: [SKNodeNormal] = []
    var lacuna: SKLacuna!
    var exercicioAtual:Int = 0
    var fichaAnimada: SKFichaAnimada!
    var opcao1: SKElementosMoveis!
    var opcao2: SKElementosMoveis!
    var opcao3: SKElementosMoveis!
    var opcao4: SKElementosMoveis!
    
    
    override func didMove(to view: SKView) {
        super.didMove(to: view)
        criarTela()
        let premissa = jogo.personagemAtual
        self.exercicio = premissa
        //        if let premissa = jogo.personagemAtual.faseAtual.exercicioAtual as? Frase {
        //            self.exercicio = premissa
        //        }
    }
    
    func criarTela() {
        let exercicioFrase = jogo.personagemAtual.faseAtual.exercicioAtual as! Frase
        estrela1 = SKNodeNormal(nomeTextura: "estrela1",
                                posicao: CGPoint(x: -420, y: -100),
                                z: 3)
        estrela1.isHidden = true
        addChild(estrela1)
        estrela2 = SKNodeNormal(nomeTextura: "estrela1",
                                posicao: CGPoint(x: -270, y: -100),
                                z: 3)
        addChild(estrela2)
        estrela2.isHidden = true
        estrela3 = SKNodeNormal(nomeTextura: "estrela1",
                                posicao: CGPoint(x: -120, y: -100),
                                z: 3)
        addChild(estrela3)
        estrela3.isHidden = true
        
        explicacao = SKMensagem(posicao: CGPoint(x: -440, y: 0),
                                texto: "Arraste a palavra correta até a lacuna. Lembre-se de usar a lógica!",
                                nomeFonte: "American Typewriter")
        addChild(explicacao)
        //ficha e elementos da ficha
        
        fichaAnimada = SKFichaAnimada(posicao: CGPoint(x: 300, y: 25), z: 2)
        addChild(fichaAnimada)
        
        
        
        enunciado = SKEnunciado(posicao: CGPoint(x: 120, y: -20), texto: exercicioFrase.enunciado, nomeFonte: "Helvetica")
        
        addChild(enunciado)
        
        lacuna = SKLacuna(posicao: CGPoint(x: 450, y: 0), z: 3, nomeTextura: "lacuna")
        addChild(lacuna)
        
        posicoesElementosMoveis = [CGPoint(x:opcao1e3x , y: opcao1e2y), CGPoint(x:opcao2e4x , y: opcao1e2y), CGPoint(x: opcao1e3x, y:opcao3e4y ), CGPoint(x:opcao2e4x , y:opcao3e4y )]
        
        for i in 0..<exercicioFrase.opcoes.count{
            elementosMoveis.append(SKElementosMoveis(posicao: posicoesElementosMoveis[i], z: 5, texto: exercicioFrase.opcoes[i]))
            addChild(elementosMoveis[i])
        }
        
        
        iconeAvancarPagina = SKIcone(manager: self, posicao: CGPoint(x: 515, y: -300), nomeTextura: "IconeAvancarPagina", id:"iconeAvancarPagina")
        iconeAvancarPagina.isHidden = true
        addChild(iconeAvancarPagina)
        
        
    }
    
    override func update(_ currentTime: TimeInterval) {
        var exercicioFrase = jogo.personagemAtual.faseAtual.exercicioAtual as! Frase
        var indiceProgresso = jogo.personagemAtual.faseAtual.indiceProgresso
        if exercicioFrase.respostas.count == 1 && indiceProgresso == 0 {
            fichaAnimada.animarFicha1()
            sumirElementos()
            if exercicioFrase.respostas == exercicioFrase.gabarito {
                estrela1.isHidden = false
            }
            
            jogo.personagemAtual.faseAtual.indiceProgresso += 1
            exercicioFrase = jogo.personagemAtual.faseAtual.exercicioAtual as! Frase
            
            print("indice progresos", indiceProgresso)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.reaparecerElementos()
                
                for i in 0..<self.elementosMoveis.count{
                    self.elementosMoveis[i].position = self.posicoesElementosMoveis[i]
                    self.elementosMoveis[i].texto.text = exercicioFrase.opcoes[i]
                }
                self.enunciado.text = exercicioFrase.enunciado
                //                        textura = SKTexture(imageNamed: exercicioFrase.enunciado)
                print(exercicioFrase.enunciado)
                
                self.elementosMoveis.append(SKElementosMoveis(posicao: self.posicoesElementosMoveis[2], z: 5, texto: exercicioFrase.opcoes[2]))
                self.addChild(self.elementosMoveis[2])
                self.reaparecerElementos()
                
            }
        }else if exercicioFrase.respostas.count == 1 && indiceProgresso == 1 {
            fichaAnimada.animarFicha2()
            sumirElementos()
            if exercicioFrase.respostas == exercicioFrase.gabarito {
                estrela2.isHidden = false
            }
            jogo.personagemAtual.faseAtual.indiceProgresso += 1
            exercicioFrase = jogo.personagemAtual.faseAtual.exercicioAtual as! Frase
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.reaparecerElementos()
                
                
                for i in 0..<self.elementosMoveis.count{
                    self.elementosMoveis[i].position = self.posicoesElementosMoveis[i]
                    self.elementosMoveis[i].texto.text = exercicioFrase.opcoes[i]
                }
                self.enunciado.text = exercicioFrase.enunciado
                //                        textura = SKTexture(imageNamed: exercicioFrase.enunciado)
                print(exercicioFrase.enunciado)
                
                self.elementosMoveis.append(SKElementosMoveis(posicao: self.posicoesElementosMoveis[3], z: 5, texto: exercicioFrase.opcoes[3]))
                self.addChild(self.elementosMoveis[3])
            }
        } else if exercicioFrase.respostas.count == 1 && indiceProgresso == 2 {
            fichaAnimada.animarFicha3()
            if exercicioFrase.respostas == exercicioFrase.gabarito {
                estrela3.isHidden = false
            }
            sumirElementos()
            setarParabens()
            
            
            
        }
    }
    
    
    
    
    func sumirElementos () {
        for elemento in elementosMoveis {
            let sumir = SKAction.fadeOut(withDuration: 0.1)
            elemento.run(sumir)
            enunciado.run(sumir)
            lacuna.run(sumir)
        }
    }
    
    func reaparecerElementos () {
        let reaparecer = SKAction.fadeIn(withDuration: 0.3)
        for elemento in elementosMoveis {
            elemento.run(reaparecer)
        }
        enunciado.run(reaparecer)
        lacuna.run(reaparecer)
        
    }
    // FIXME: Colocar texto certo
    func setarParabens () {
        explicacao.text = "Parabéns, você conseguiu!"
        iconeAvancarPagina.isHidden = false
    }
    // FIXME: Colocar texto certo
    func setarTenteDeNovo () {
        explicacao.text = ""
    }
    
    // FIXME: Não posso override, botao voltar parou de funcionar
    
    override func tocouEm(id: String) {
        
        switch id {
        case "iconeAvancarPagina":
            if let novaCena = TelaAdaConclusao(fileNamed: "TelaAdaConclusao"){
                novaCena.scaleMode = .aspectFill
                self.view?.presentScene(novaCena)
            }
        default:
            break
            
        }
    }
}
