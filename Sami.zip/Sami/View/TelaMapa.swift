//
//  TelaMapa.swift
//  Sami
//
//  Created by Maria Gorette Soares Tavares on 11/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import Foundation
import SpriteKit

class TelaMapa:SKScene {
    
    var fundo : SKFundoTelas!
    var iconeBiblio : SKIcone!
    var iconeFliperama : SKIcone!
    var iconeParque : SKIcone!
    var iconePorto : SKIcone!
    var iconeLaboratorio : SKIcone!
    var iconeSami: SKIcone!
 

    
    override func didMove(to view: SKView) {
    
        criarElementos()
        ativarParticula()

    }
    

    func criarElementos (){
        fundo = SKFundoTelas(nomeTextura: "BackMapa")
        addChild(fundo)
        iconeSami = SKIcone(manager: self, posicao: CGPoint(x: -530, y: -250), nomeTextura: "SamiIcone", id: "iconeSami")
        iconeSami.setScale(0.6)
        addChild(iconeSami)

        iconeBiblio = SKIcone(manager: self, posicao: CGPoint(x: 0, y: 120), nomeTextura: "IconeBiblio", id: "iconeBiblio")
        addChild(iconeBiblio)
//        iconeFliperama = SKIcone(manager: self, posicao: CGPoint(x: 0, y: 0), nomeTextura: "IconeFliperama", id: "iconeFliperama")
//        addChild(iconeFliperama)
//        iconeParque = SKIcone(manager: self, posicao: CGPoint(x: 0, y: 0), nomeTextura: "IconeParque", id: "iconeParque")
//        addChild(iconeParque)
//        iconePorto = SKIcone(manager: self, posicao: CGPoint(x: 0, y: 0), nomeTextura: "IconePorto", id: "iconePorto")
//        addChild(iconePorto)
//        iconeLaboratorio = SKIcone(manager: self, posicao: CGPoint(x: 0, y: 0), nomeTextura: "IconeLaboratorio", id: "iconeLaboratorio")
//        addChild(iconeLaboratorio)
        
        
    }
    
    func ativarParticula() {
        let nuvemParticula = Bundle.main.path(forResource: "nuvemParticula", ofType: "sks")
        let particula = NSKeyedUnarchiver.unarchiveObject(withFile: nuvemParticula!) as! SKEmitterNode
        particula.position = CGPoint(x: -700, y: 0)
        particula.particleScale = 0.9
        self.addChild(particula)
    }
    

    
}

extension TelaMapa: ElementosManager {


    func tocouEm(id: String) {
        
        switch id {
            
        case "iconeBiblio":
            print("icone biblio tocado")
            if let novaCena = Biblioteca(fileNamed: "Biblioteca"){
                novaCena.scaleMode = .aspectFill
//                let transition = SKTransition.moveIn(with: .right, duration: 0.3)
                self.view?.presentScene(novaCena)
            }
//        case "iconeFliperama":
//            if let novaCena = Fliperama(fileNamed: "Fliperama"){
//                novaCena.scaleMode = .aspectFill
//                let transition = SKTransition.moveIn(with: .right, duration: 0.3)
//                self.view?.presentScene(novaCena, transition: transition)
//            }


//        case "iconePorto":
//            if let novaCena = Porto(fileNamed: "Porto"){
//                novaCena.scaleMode = .aspectFill
//                let transition = SKTransition.moveIn(with: .right, duration: 0.3)
//                self.view?.presentScene(novaCena, transition: transition)
//            }

//        case "iconeParque":
//            if let novaCena = Parque(fileNamed: "Parque"){
//                novaCena.scaleMode = .aspectFill
//                let transition = SKTransition.moveIn(with: .right, duration: 0.3)
//                self.view?.presentScene(novaCena, transition: transition)
//            }
            
            
//        case "iconeLaboratorio":
//            if let novaCena = Laboratorio(fileNamed: "Laboratorio"){
//                novaCena.scaleMode = .aspectFill
//                let transition = SKTransition.moveIn(with: .right, duration: 0.3)
//                self.view?.presentScene(novaCena, transition: transition)
//            }
        case "iconeSami":
            if let novaCena = TelaSami(fileNamed: "TelaSami"){
                novaCena.scaleMode = .aspectFill
                self.view?.presentScene(novaCena)
            }

            
        default:
            print("nao tocou")
        }
        

    }



}

// puxar elementos: background e Iconebiblio
// posicionar elementos

// função mudar para Biblioteca
// quando Iconebiblio for tocado
// mudar para Biblioteca
