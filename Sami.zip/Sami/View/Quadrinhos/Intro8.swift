//
//  Intro8.swift
//  Sami
//
//  Created by Maria Gorette Soares Tavares on 10/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import Foundation
import SpriteKit

// Gorette
class Intro8:SKIntroMaster {
    
    var sami:SKSamiAnimado?
    var iconeAvancar:SKBotaoAvancar?
    var fundo:SKFundoTelas
    var barraCarregamento:SKBarraCarregamento?
    var aviso:SKAvisoCrop?
    
    init(manager: IntroManager) {
        self.fundo = SKFundoTelas(nomeTextura: "FundoGira")
        self.fundo.alpha = 0
        self.fundo.setScale(0.8)
        self.fundo.zPosition = 2
        super.init(manager: manager, imageNamed: "BackDefault", direction: .none)
        addChild(fundo)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
            let fadeOut = SKAction.fadeOut(withDuration: 3)
            self.aviso?.run(fadeOut)
        }
        
        
        criarElementos()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func criarElementos() {
        let sami = SKSamiAnimado(manager: self, posicao: CGPoint(x: 58, y: 47), z: 8)
        addChild(sami)
        self.sami = sami
        
        let mao = SKNodeNormal(nomeTextura: "Mao",
                               posicao: CGPoint(x: 22, y: -207.924),
                               z: 15)
        addChild(mao)
    
        let avancar = SKBotaoAvancar(manager: self,
                                     posicao: CGPoint(x: 580, y: -300),
                                     z: 10)
        avancar.isHidden = true
        self.iconeAvancar = avancar
        addChild(avancar)
        
        let progressBar = SKBarraCarregamento(imagemPreenchimento: "BackIntro8")
        progressBar.zPosition = 3
        progressBar.position = CGPoint(x: 0, y: 0)
        self.barraCarregamento = progressBar
        addChild(progressBar)
        
        let aviso = SKAvisoCrop(tamanho: CGSize(width: 250, height: 80), texto: "Agite!")
        aviso.position = CGPoint(x: 0, y: 280)
        aviso.zPosition = 10
        self.aviso = aviso
        addChild(aviso)
    }
    
    func mudarFundo() {
        let alfa = SKAction.fadeAlpha(to: 1, duration: 0.3)
        let girar = SKAction.rotate(byAngle: 1.5, duration: 1)
        fundo.run(alfa)
        fundo.run(SKAction.repeatForever(girar))
    }
    
}

extension Intro8: ElementosManager, BarraCarregamentoManager {
    func tocouEm(id: String) {
        switch id {
        case "Avançar":
            acabei()
        default:
            break
        }
    }
    
    func carregandoSami(contagem: CGFloat) {
        barraCarregamento?.alterarProgressoY(valor: contagem)
    }
    
    func fimDoCarregamento() {
        sami?.acordaSami()
        mudarFundo()
        iconeAvancar?.isHidden = false
        barraCarregamento?.isHidden = true
        aviso?.isHidden = true
        
        let efeitoParticula = Bundle.main.path(forResource: "EfeitoParticulas", ofType: "sks")
        let particula = NSKeyedUnarchiver.unarchiveObject(withFile: efeitoParticula!) as! SKEmitterNode
        particula.position = self.position
        particula.zPosition = 5
        self.addChild(particula)
    }
 
}
