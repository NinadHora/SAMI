//
//  Intro1.swift
//  Sami
//
//  Created by Maria Gorette Soares Tavares on 10/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import Foundation
import SpriteKit


enum ScrollDirection {
    case horizontal
    case vertical
    case freeStyle
    case none
}

protocol Parallaxable {
    var parallaxFactor:CGFloat {get set}
}


class SKIntroMaster: SKSpriteNode {
    
    var manager: IntroManager
    var direction:ScrollDirection
    var positionsForEvents:[(position: CGPoint, valid:Bool)] = []
    var posicaoFinal:CGPoint = CGPoint.zero

    var limiteXMod:CGFloat {
        
        if let scene = self.parent as? SKScene {
            let width = scene.size.width / 2
            return self.size.width / 2.0 - width
        }
        return 0
    }
    var limiteYMod:CGFloat {
        
        if let scene = self.parent as? SKScene {
            let height = scene.size.height / 2
            return self.size.height / 2.0 - height
        }
        return 0
    }
    
    var limite:CGPoint {
        return CGPoint(x: limiteXMod, y: limiteYMod)
    }

    
    init(manager: IntroManager, imageNamed:String, posicao: CGPoint = CGPoint(x: 0, y: 0), direction:ScrollDirection) {
        self.manager = manager
        let textura = SKTexture(imageNamed: imageNamed)
        let tamanho = textura.size()
        self.direction = direction
        super.init(texture: textura, color: .clear, size: tamanho)
        
        self.posicaoFinal = posicao
        self.position = posicao
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func acabei(){
        manager.fimDeCena()
    }
    
    
    func runWithParallax(deslocamentoX dx:CGFloat, deslocamentoY dy:CGFloat, slideFactor: Double) {
        // Ações que movimentam os quadrinhos na horizontal e vertical
        var deslocamentoX = dx * 4.0
        var deslocamentoY = -dy * 4.0
        
        switch self.direction {
        case .none:
            deslocamentoX = 0.0
            deslocamentoY = 0.0
        case .vertical:
            deslocamentoX = 0.0
        case .horizontal:
            deslocamentoY = 0.0
        case .freeStyle:
            break
        }
        
        self.move(to: CGPoint(x: deslocamentoX, y: deslocamentoY))


    }
    
    
    func move(to destinyPoint: CGPoint) {
        self.posicaoFinal = (self.posicaoFinal + destinyPoint)
        self.posicaoFinal.limitMod(self.limite)
        let moverQuadrinho = SKAction.move(to: posicaoFinal, duration: 1/30)
        self.run(moverQuadrinho)
        
        
        
        for child in self.children {
            if let movingChild = child as? Parallaxable {
                let destinyPoint = destinyPoint * movingChild.parallaxFactor
                let parallaxMovment = SKAction.moveBy(x: destinyPoint.x, y: destinyPoint.y, duration: 1/30)
                child.run(parallaxMovment)
                
            }
        }
        
        self.getScroolEvent(in: posicaoFinal)
    }
    
    // função que observa em que posição o scrool está
    func addObserverdScroolEvents(in positions: [CGPoint]) {
        // para um item das muitas posições
        for item in positions {
            //instancia a posição do item/evento na posição especifica
            // retorna uma posição e uma validação (que pode ser usado para caso eu queira desvalidar)
            let positionEvent:(position: CGPoint, valid:Bool) = (position: item, valid:true)
            //cria uma lista de posições para eventos
            self.positionsForEvents.append(positionEvent)
        }
        //
        
        self.positionsForEvents.sort {
            //sort nas posições
            // $0 - primeiro parâmetro    $1 - segundo parâmetro
            // operador ternário -->  question ? answer1 : answer2  -- ou seja, se a pergunta for certa, valida a resposta 1, senão valida a resposta 2
            // se a posição.x do primeiro for diferente da posição.x do segundo, a posição.x do primeiro vai ser menor que a posição.x do segundo, senão a posição.y do primeiro vai ser menor que a posição.y do segundo
            //  -- ou seja:   se a posição x for igual, ele calcula o y (pq o scrool é vertical); se a x for diferente ele calcula o x mesmo
            $0.position.x != $1.position.x ? $0.position.x < $1.position.x : $0.position.y < $1.position.y
            
        }
    }
    
    //aciona o evento na posição
    func getScroolEvent(in position: CGPoint) {
        //para um index que seja menor que a contagem total de index das posições // ou seja, que não seja o último
        for i in 0..<positionsForEvents.count {
            // se o evento do index é válido
            if positionsForEvents[i].valid {
                // e se a posição atual do quadro é maior que a posição do index do evento checado
                if position.isBigger(than: positionsForEvents[i].position) {
                    print("posição atual:", position)
                    // e se o evento é o último
                    if i == positionsForEvents.count-1 {
                        // evento ocorreu
                        runActionFor(event: i)
                    // e se o evento não é o último - adiciona um index na contagem de evento
                    } else if positionsForEvents[i+1].position.isBigger(than: position) {
                        // evento ocorreu
                        runActionFor(event: i)
                    }
                }
            }
        }
    }
    
    
    func runActionFor(event: Int) {
        print("evento de scrool", event, "ocorreu")
        

    }
    
    
    
    
//    func deslocamentoLimitado(deslocamentoX: CGFloat)->CGFloat {
//        let deslocamento = self.position.x + deslocamentoX
////        print(limiteXMod)
////        print(deslocamento)
//        if deslocamento > limiteXMod {
//            print(self.position.x - limiteXMod)
//            return limiteXMod
//        } else if deslocamento < -limiteXMod {
//            return self.position.x + limiteXMod
//        }
//        return deslocamentoX
//    }
//
//    func deslocamentoLimitadoY(deslocamentoY: CGFloat)->CGFloat {
//        let posicao = self.position.y
//        let mover1 = SKAction.moveTo(y: limiteYMod, duration: 0.5)
//        let mover2 = SKAction.moveTo(y: -limiteYMod, duration: 0.5)
//        if posicao > limiteYMod {
//            self.run(mover1)
//        } else if posicao < -limiteYMod {
//            self.run(mover2)
//        }
//        return deslocamentoY
//    }
    
}


