//
//  Intro10.swift
//  Sami
//
//  Created by Maria Gorette Soares Tavares on 17/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import Foundation
import SpriteKit


class Intro10:SKIntroMaster {
    
    
    init(manager: IntroManager) {
        super.init(manager: manager, imageNamed: "BackIntro10", direction: .none)
        criarElementos()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func criarElementos() {
        let avancar = SKBotaoAvancar(manager: self,
                                     posicao: CGPoint(x: 580, y: -300),
                                     z: 10)
        addChild(avancar)
    }
    
    
}

extension Intro10: ElementosManager {
    func tocouEm(id: String) {
        switch id {
        case "Avançar":
            acabei()
        default:
            break
        }
    }
}
