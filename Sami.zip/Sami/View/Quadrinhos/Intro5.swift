//
//  Intro5.swift
//  Sami
//
//  Created by Maria Gorette Soares Tavares on 10/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import Foundation
import SpriteKit

// Gorette
class Intro5:SKIntroMaster {
    
    var portaAnimada:SKPortaAnimada?
    var caixaToque:SKReferenciaToque?
    var caixa:SKCaixa?
    
    init(manager: IntroManager) {
        super.init(manager: manager, imageNamed: "BackIntro5", direction: .none)
        
        self.caixaToque = SKReferenciaToque(manager: self,
                                            id: "CaixaToque",
                                            tamanho: CGSize(width: 231, height: 135),
                                            posicao: CGPoint(x: 10, y: -195),
                                            z: 10)
        addChild(caixaToque!)
        
        criarElementos()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func criarElementos() {
        let porta = SKPortaAnimada(manager: self, posicao: CGPoint(x: 90, y: -35), z: 8)
        addChild(porta)
        let caixa = SKCaixa(manager: self, posicao: CGPoint(x: 10, y: -195), z: 5)
        addChild(caixa)
        let quadro = SKQuadro(manager: self, posicao: CGPoint(x: -450, y: 100), z: 2)
        addChild(quadro)
        
        self.caixa = caixa
        self.portaAnimada = porta
    }
}

extension Intro5: ElementosManager {
    
    func tocouEm(id: String) {
        
        switch id {
        case "PortaAnimada":
            portaAnimada?.animarPorta()
        case "CaixaToque":
            caixa?.animarCaixa()
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                if self.portaAnimada?.portaAberta == true {
                    self.acabei()
                } else if self.portaAnimada?.portaAberta == false {
                    self.portaAnimada?.animarPorta()
                }
            }
        default:
            break
        }
        
    }
    
}
