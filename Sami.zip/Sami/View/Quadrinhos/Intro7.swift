//
//  Intro7.swift
//  Sami
//
//  Created by Maria Gorette Soares Tavares on 10/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import Foundation
import SpriteKit

// Gorette
class Intro7:SKIntroMaster {
    
    var meninoCorrendo: SKNodeNormal?
    
    init(manager: IntroManager) {
        
        let backPosition = CGPoint(x: 1333.5, y: 0)
        super.init(manager: manager, imageNamed: "BackIntro7", posicao: backPosition, direction: .horizontal)
        
        self.addObserverdScroolEvents(in: [CGPoint(x: 2000, y: 0)])
        criarElementos()
        
//        runActionFor(event: 0)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func criarElementos() {
        
        let sami = SKModelo(manager: self,
                            nomeTextura: "SamiIntro7",
                            id: "Sami",
                            posicao: CGPoint(x: 1160, y: -108.5),
                            z: 10)
        addChild(sami)
        
        
        let menino1 = SKMeninoAnimado(manager: self, posicao: CGPoint(x: -1108, y: 47), z: 11, nomeTextura: "MeninoAnimado1.1")
        addChild(menino1)
        
        let menino2 = SKMeninoAnimado(manager: self, posicao: CGPoint(x: -310, y: 47), z: 11, nomeTextura: "MeninoAnimado2.1")
        addChild(menino2)
        
        let menino3 = SKMeninoAnimado(manager: self, posicao: CGPoint(x: 480, y: 47), z: 11, nomeTextura: "MeninoAnimado3.1")
        addChild(menino3)
        
        menino1.animarMenino1()
        menino2.animarMenino2()
        menino3.animarMenino3()
        
        
        let correndo = SKNodeNormal(nomeTextura: "Correndo", posicao: CGPoint(x: 1600, y: 100), z: 15, itemParallaxFactor: 0)
        self.meninoCorrendo = correndo
        addChild(correndo)
        
    }
    
    func desaparecer()  {
        let diminuir = SKAction.scale(to: 0.1, duration: 15.0)
        meninoCorrendo?.run(diminuir)
        let desaparecer = SKAction.fadeOut(withDuration: 15.0)
        meninoCorrendo?.run(desaparecer)
       
    }
    
    
    override func runActionFor(event: Int) {
        if event == 0 {
            desaparecer()
            print("esse event é", event)
            super.runActionFor(event: event)
            self.positionsForEvents[event].valid = false
            print("Oi, eu sou o intro 7")
        }
    }
    
}

extension Intro7: ElementosManager {
    
    func tocouEm(id: String) {
        switch id {
        case "Sami":
            if self.position.x < -1280.0 {
                acabei()
            }

        default:
            break
        }
    }
}
