//
//  Intro11.swift
//  Sami
//
//  Created by Maria Gorette Soares Tavares on 17/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import Foundation
import SpriteKit

//
class Intro11:SKIntroMaster {
    
    var balaoMenina:SKBalao?
    var balaoSami: SKBalao?
    var balaoEscolha: SKBalao?
    var falasSami: [String]
    var falasMenina: [String]
    var contadorSami: Int = 0
    var contadorMenina: Int = 0
    var avancar: SKBotaoAvancar?
    
    init(manager: IntroManager) {
        self.falasSami = ["Oi! Eu sou a Sami! Onde eu estou? Sabe porque eu to aqui?",
                          "Que estranho…  Só consigo lembrar de um nome! Ada Lovelace!",
                          "Não sei bem, mas podemos procurar na biblioteca!",
                          "Eu tenho um mapa!"]
        self.falasMenina = ["Não sei… Alguém deixou você em minha porta",
                            "O que é isso?",
                            "Como podemos chegar até lá?"]
        super.init(manager: manager, imageNamed: "BackIntro11", direction: .none)
        criarElementos()
        falaSami(texto: falasSami[contadorSami])
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func criarElementos(){
        let enquadramento = SKNodeNormal(nomeTextura: "Enquadramento", posicao: CGPoint(x: 0, y: 0) , z: 30)
        let sami = SKSami(manager: self, posicao: CGPoint(x: 0, y: 50), z: 9, nomeTextura: "SamiForma", samiAnimado: true)
        let mao = SKNodeNormal(nomeTextura: "Mao", posicao: CGPoint(x: 13, y: -130), z: 10)
        let avancar = SKBotaoAvancar(manager: self, posicao: CGPoint(x: 580, y: -300), z: 35)
        
        mao.setScale(0.8)
        sami.setScale(0.9)
        addChild(enquadramento)
        addChild(sami)
        addChild(mao)
        addChild(avancar)
        avancar.isHidden = true
        self.avancar = avancar
    }
    
    func falaSami(texto: String) {
        let balao = SKBalao(manager: self,
                            posicao: CGPoint(x: -400, y: 200),
                            z: 35,
                            nomeTextura: "BalaoFinal",
                            texto: falasSami[contadorSami],
                            id: "FalaSami")
        self.balaoSami = balao
        self.addChild(balao)
        balao.animarBalao()
//        self.animarBalao(elemento: balao)
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            self.contadorSami += 1
            if self.contadorMenina < self.falasMenina.count {
                self.aparecerEscolha(texto: self.falasMenina[self.contadorMenina])
            } else {
                self.avancar?.isHidden = false
            }
        }
    }
    
    func aparecerEscolha(texto: String){
        let escolha = SKBalao(manager: self,
                              posicao: CGPoint(x: 340, y: -290),
                              z: 35,
                              nomeTextura: "BalaoEscolha",
                              texto: self.falasMenina[self.contadorMenina],
                              id: "Escolha")
//        escolha.texto.preferredMaxLayoutWidth = 400
        self.balaoEscolha = escolha
        self.addChild(escolha)
    }
    
    func enviarBalaoMenina(fala: Int){
        let balao = SKBalao(manager: self,
                            posicao: CGPoint(x: 400, y: -240),
                            z: 11,
                            nomeTextura: "BalaoFinal",
                            texto: falasMenina[fala],
                            id: "FalaMenina")
        self.balaoMenina = balao
        self.addChild(balao)
        subirBalao(elemento: balao)
    }
    
//    func animarBalao(elemento:SKBalao) {
//        let aumentaBalao = SKAction.scale(to: 1.1, duration: 0.2)
//        let diminuiBalao = SKAction.scale(to: 0.9, duration: 0.2)
//        let pararBalao = SKAction.scale(to: 1.0, duration: 0.2)
//        let animar = SKAction.sequence([aumentaBalao, diminuiBalao, pararBalao])
//        elemento.run(animar)
//    }
    
    func subirBalao(elemento:SKBalao) {
        let mover = SKAction.moveTo(y: -70, duration: 0.3)
        elemento.run(mover)
    }
    
}

extension Intro11: ElementosManager {
    func tocouEm(id: String) {
        switch id {
        case "Escolha":
            enviarBalaoMenina(fala: contadorMenina)
            balaoEscolha?.removeFromParent()
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                self.balaoSami?.removeFromParent()
                self.balaoMenina?.removeFromParent()
                self.contadorMenina += 1
                print(self.contadorMenina)
                self.falaSami(texto: self.falasSami[self.contadorSami])
            }
        case "Avançar":
            acabei()
        default:
            break
        }
    }
}

