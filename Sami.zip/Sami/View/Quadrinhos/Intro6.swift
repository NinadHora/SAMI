//
//  Intro6.swift
//  Sami
//
//  Created by Maria Gorette Soares Tavares on 10/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import Foundation
import SpriteKit

class Intro6:SKIntroMaster {
    
    var iconeAvancar:SKBotaoAvancar?
    
    init(manager: IntroManager) {
        let backPosition = CGPoint(x: 0, y: 0)
        super.init(manager: manager, imageNamed: "BackIntro6", posicao: backPosition, direction: .none)
        criarElementos()
        iconeAvancar?.isHidden = true
    }
    
    func criarElementos(){
        let caixaAbrindo = SKCaixaAbrindo(manager: self, posicao: CGPoint(x: -20, y: 0), z: 10, nomeTextura: "CaixaAnimada1")
        self.addChild(caixaAbrindo)
        
        let avancar = SKBotaoAvancar(manager: self,
                                     posicao: CGPoint(x: 580, y: -300),
                                     z: 10)
        avancar.zPosition = 20
        avancar.isHidden = true
        self.iconeAvancar = avancar
        addChild(avancar)
        
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    
}


extension Intro6:ElementosManager{
    func tocouEm(id: String) {
        switch id {
            
        case "CaixaAnimada3":
            iconeAvancar?.isHidden = false
        case "Avançar":
            acabei()
        default:
            break
        }
    }
}
