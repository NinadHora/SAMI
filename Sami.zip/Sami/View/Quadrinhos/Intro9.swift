//
//  Intro9.swift
//  Sami
//
//  Created by Maria Gorette Soares Tavares on 10/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import Foundation
import SpriteKit

//Bruna
class Intro9:SKIntroMaster {
    
    init(manager: IntroManager) {
        let backPosition = CGPoint(x: 0, y: -1125.5)
        super.init(manager: manager, imageNamed: "BackIntro9", posicao: backPosition, direction: .vertical)
        criarElementos()
        
    }
    
    func criarElementos() {
        let sami = SKSami(manager: self, posicao: CGPoint(x: 150.5, y: -1155), z: 10, nomeTextura: "SamiIntro9", samiAnimado: false)
        addChild(sami)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func runActionFor(event: Int) {
        super.runActionFor(event: event)
//        self.positionsForEvents[event].valid = false
        print("Oi, eu sou o intro 9")
    }
}

extension Intro9: ElementosManager {
    func tocouEm(id: String) {
        switch id {
        case "Sami":
            if self.position.y > 1120.0 {
                print(self.position.y)
                acabei()
            }
        default:
            break
        }
    }
}
