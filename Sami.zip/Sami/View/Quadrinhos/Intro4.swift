//
//  Intro4.swift
//  Sami
//
//  Created by Maria Gorette Soares Tavares on 10/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import Foundation
import SpriteKit

class Intro4:SKIntroMaster {
    
    init(manager: IntroManager) {
        let backPosition = CGPoint(x: 463, y: 0)
        super.init(manager: manager, imageNamed: "BackIntro4", posicao: backPosition, direction: .horizontal)
        criarElementos()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func criarElementos(){
        let menina = SKMeninaCorrendo(manager: self, posicao: CGPoint(x: -50, y: -40), z: 10)
        menina.setScale(0.8)
        self.addChild(menina)
        
        
        let porta = SKPorta(manager: self, posicao: CGPoint(x: 1100, y: 0), z: 12, nomeTextura: "PortaIntro4")
        self.addChild(porta)
        
        let movel = SKNodeNormal(nomeTextura: "Moveis", posicao: CGPoint(x: 600, y: -200), z: 14, itemParallaxFactor: 1.2)
        self.addChild(movel)
    
    
    }
    //parallax
    //limitação no scroll
   
}

extension Intro4:ElementosManager{
    func tocouEm(id: String) {
        switch id {
        case "Porta":
            acabei()
        default:
            break
        }
    }
}

