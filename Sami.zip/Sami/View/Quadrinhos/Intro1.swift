//
//  Intro1.swift
//  Sami
//
//  Created by Maria Gorette Soares Tavares on 10/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import Foundation
import SpriteKit


// Gorette
class Intro1: SKIntroMaster {
    
    
    init(manager: IntroManager) {
        super.init(manager: manager, imageNamed: "BackIntro1", direction: .freeStyle)
        ativarParticular()
        criarElementos()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func criarElementos() {
        let casa = SKCasa(manager: self, posicao: CGPoint(x: 240.2, y: 69), z: 10)
        self.addChild(casa)
        
        let wait = SKAction.wait(forDuration: 0.3)
        run(wait)
        
        let mexeCasa = SKAction.scale(to: 1.02, duration: 0.2)
        let mexeCasadeVolta = SKAction.scale(to: 1, duration: 0.2)
        let sequencia = SKAction.sequence([ mexeCasa, mexeCasadeVolta])
        let repeatAcao = SKAction.repeat(sequencia, count: 4)
        casa.run(repeatAcao)
        
    }
    
    func ativarParticular() {
        let nuvemParticula = Bundle.main.path(forResource: "nuvemParticula", ofType: "sks")
        let particula = NSKeyedUnarchiver.unarchiveObject(withFile: nuvemParticula!) as! SKEmitterNode
        particula.position = CGPoint(x: -700, y: 0)
        self.addChild(particula)
    }

    
}

extension Intro1:ElementosManager{
    func tocouEm(id: String) {
        
        switch id {
        case "CasaIntro1":
            acabei()
            print("foiii")
        default:
            print("nao foi")
        }
        
    }
}
