//
//  Intro2.swift
//  Sami
//
//  Created by Maria Gorette Soares Tavares on 10/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import Foundation
import SpriteKit

class Intro2: SKIntroMaster {
    
    init(manager: IntroManager) {
        let backPosition = CGPoint(x: 0, y: 0)
        super.init(manager: manager, imageNamed: "BackIntro2", posicao: backPosition, direction: .none)
      
        criarElementos()
    }
    
    func criarElementos(){
        //adiciona o node da porta no lugar certo
        let porta = SKPorta(manager: self, posicao: CGPoint(x: -112, y: -102), z: 10, nomeTextura: "Porta1Intro2" )
        self.addChild(porta)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    

}


//Intro 1 assina o protocolo por meio da extensão
extension Intro2:ElementosManager{
    func tocouEm(id: String) {
        switch id {
        case "Porta":
            acabei()
        default:
            break
        }
    }
}
