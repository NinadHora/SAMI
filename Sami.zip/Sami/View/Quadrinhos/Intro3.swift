//
//  Intro3.swift
//  Sami
//
//  Created by Maria Gorette Soares Tavares on 10/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import Foundation
import SpriteKit

class Intro3:SKIntroMaster {
    
    
    init(manager: IntroManager) {
        let backPosition = CGPoint(x: 665, y: 0)
        super.init(manager: manager, imageNamed: "BackIntro3", posicao: backPosition, direction: .horizontal)
        criarElementos()
    }
    
    func criarElementos(){
        //instacia quadro
        let quadro = SKQuadro(manager: self, posicao: CGPoint(x: -1130, y: 200), z: 10)
        self.addChild(quadro)
        
        //instancia crianças
        let criancas = SKCriancaAnimada(manager: self, posicao: CGPoint(x: -640, y: -170), z: 13)
        criancas.setScale(0.95)
        self.addChild(criancas)
        
        let dingdong = SKDingDong(manager: self, posicao: CGPoint(x: -140, y: 130), z: 13)
        self.addChild(dingdong)
        dingdong.isHidden = true
        
        let icone = SKBotaoAvancar(manager: self, posicao: CGPoint(x: 1250, y: -300), z: 10)
        self.addChild(icone)
        
        let cartas = SKNodeNormal(nomeTextura: "Cartas", posicao: CGPoint(x: -750, y: -350), z: 12, itemParallaxFactor: 0.25)
        self.addChild(cartas)
        
        let tapete = SKNodeNormal(nomeTextura: "Tapete", posicao: CGPoint(x: -660, y: -310), z: 11, itemParallaxFactor: 0.35)
        self.addChild(tapete)
        
        
        //delay actions: dingdong apareceu e textura crianças mudou
        let delay = SKAction.wait(forDuration: 0.8)
        let delay2 = SKAction.wait(forDuration: 0.5)
       
        dingdong.run(delay) {
            dingdong.isHidden = false
            print("deu delay")
          
            let mexeQuadro = SKAction.rotate(toAngle: CGFloat(0.1), duration: 0.2)
            let mexeNovamente = SKAction.rotate(toAngle: CGFloat (-(0.1)), duration: 0.2)
            let mexeMaisRapido = SKAction.rotate(toAngle: CGFloat(0.05), duration: 0.1)
            let mexeMaisRapidoNovamente = SKAction.rotate(toAngle: CGFloat (-(0.05)), duration: 0.1)
            let sequence = SKAction.sequence([delay2, mexeQuadro, mexeNovamente, mexeMaisRapido, mexeMaisRapidoNovamente])
            quadro.run(SKAction.repeat(sequence, count: 2))
            
            criancas.run(delay2) {
                criancas.mudouTextura()
                print("deu delay2")
            }
        }
        
        
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }



}

extension Intro3:ElementosManager{
    func tocouEm(id: String) {
        switch id {
        case "Avançar":
            acabei()
        default:
            break
        }
    }
}
