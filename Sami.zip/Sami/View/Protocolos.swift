//
//  Protocolos.swift
//  Sami
//
//  Created by Maria Gorette Soares Tavares on 12/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import SpriteKit

protocol IntroManager {
    func fimDeCena()
}

//usado na classe dos elementos e nas intro/cenas
protocol ElementosManager {
    func tocouEm(id:String)
}

protocol BarraCarregamentoManager {
    func carregandoSami(contagem: CGFloat)
    func fimDoCarregamento()
}
