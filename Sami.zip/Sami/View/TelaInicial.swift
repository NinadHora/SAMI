//
//  TelaInicial.swift
//  Sami
//
//  Created by Bruna Tardioli on 20/01/19.
//  Copyright © 2019 DaHora. All rights reserved.
//

import Foundation
import SpriteKit

class TelaInicial:SKScene{
    
    var manager: ElementosManager!
    var labelIniciar: SKLabelNode!
    var id: String!
    
    
    override func didMove(to view: SKView) {
        criarElementos()
    }
    
    
    func criarElementos() {
        let fundo = SKFundoTelas(nomeTextura: "BackTelaInicial")
        addChild(fundo)
        fundo.setScale(0.57)
        
        let botaoIniciar = SKIcone(manager: self, posicao: CGPoint(x: 5, y: -145), nomeTextura: "BotaoIniciar", id: "Iniciar")
        addChild(botaoIniciar)
        botaoIniciar.setScale(0.6)
        
        self.labelIniciar = SKLabelNode(text: "Iniciar")
        self.labelIniciar.numberOfLines = 1
        self.labelIniciar.position = CGPoint(x: 0, y: -140)
        self.labelIniciar.horizontalAlignmentMode = .center
        self.labelIniciar.verticalAlignmentMode = .center
        self.labelIniciar.fontSize = 28
        self.labelIniciar.fontName = "IstokWeb-Bold"
        self.labelIniciar.fontColor = #colorLiteral(red: 0.3574119607, green: 0.3574119607, blue: 0.3574119607, alpha: 1)
        self.labelIniciar.lineBreakMode = NSLineBreakMode.byWordWrapping
        self.labelIniciar.zPosition = 15
        self.labelIniciar.preferredMaxLayoutWidth = 80
        addChild(self.labelIniciar)
    }
    
    
    func mudarCena(){
        let novaCena = SKScene(fileNamed: "TelaQuadrinho")!
        novaCena.scaleMode = .aspectFill
        let transition = SKTransition.moveIn(with: .right, duration: 0.05)
        self.view?.presentScene(novaCena, transition: transition)
    }
}

extension TelaInicial: ElementosManager {
    
    func tocouEm(id: String) {
        switch id {
        case "Iniciar":
            mudarCena()
            
        default:
            break
        }
        
    }
    
}


