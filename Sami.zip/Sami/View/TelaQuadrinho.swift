//
//  TelaExercicio.swift
//  Sami
//
//  Created by Ana Da hora on 30/11/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

// bruna e gorette
import Foundation
import SpriteKit
import GameplayKit
import CoreMotion

class TelaQuadrinho:SKScene {
    
    var quadrinhoAtual:Int = 0
    var cenasIntro:[SKIntroMaster] = []
    
    var manager: BarraCarregamentoManager!
    
    var motionManager = CMMotionManager()
    var contagem:CGFloat  = 0.0
    
    var anteriorValorX:Double = 0
    var valorX:Double = 0
    var deslocamento:Double = 0
    
    //translação prévia - 0x 0y (sem variação de movimento)
    var deslocamentoAnteriorX:CGFloat = 0.0
    var deslocamentoAnteriorY:CGFloat = 0.0
    
    
    override func didMove(to view: SKView) {
        
        criarQuadrinhos()
        configuraGestos()
        apresentarQuadrinho(numero: quadrinhoAtual)
        
        motionManager.startAccelerometerUpdates()
    }

    
    //coleção de quadrinhos
    func criarQuadrinhos() {
        let intro1 = Intro1(manager: self)
        let intro2 = Intro2(manager: self)
        let intro3 = Intro3(manager: self)
        let intro4 = Intro4(manager: self)
        let intro5 = Intro5(manager: self)
        let intro6 = Intro6(manager: self)
        let intro7 = Intro7(manager: self)
        let intro8 = Intro8(manager: self)
        let intro9 = Intro9(manager: self)
        let intro10 = Intro10(manager: self)
        let intro11 = Intro11(manager: self)
        
        cenasIntro.append(intro1)
        cenasIntro.append(intro2)
        cenasIntro.append(intro3)
        cenasIntro.append(intro4)
        cenasIntro.append(intro5)
        cenasIntro.append(intro6)
        cenasIntro.append(intro7)
        cenasIntro.append(intro8)
        cenasIntro.append(intro9)
        cenasIntro.append(intro10)
        cenasIntro.append(intro11)
        manager = intro8
    }
    
    // Recohecer o pan como um gesto
    private func configuraGestos() {
        let pan = UIPanGestureRecognizer(target: self, action: #selector(handlePan(pan:)))
        self.view!.addGestureRecognizer(pan)
    }
    
    // O que o gesto faz
    @objc private func handlePan(pan:UIPanGestureRecognizer) {
        
        //translação do pan - valor do quanto deslocou o dedo
        let translacaoX = pan.translation(in: self.view).x
        let translacaoY = pan.translation(in: self.view).y
        
        // diferença entre o quanto vc deslocou e a translação anterior
        let deslocamentoX = translacaoX - deslocamentoAnteriorX
        let deslocamentoY = translacaoY - deslocamentoAnteriorY
        
        // Velocidade para fazer o quadrinho escorregar
        let velocidade = pan.velocity(in: self.view)
        let magnitude = sqrt((velocidade.x * velocidade.x) + (velocidade.y * velocidade.y))
        let slideMultiplier = magnitude / 200
        let slideFactor = Double(0.1 * slideMultiplier)
        

        //único quadrinho atual (self.children.first) - indentifica o tipo de scroll que ele terá
        if let quadrinho = self.children.first as? SKIntroMaster {
            quadrinho.runWithParallax(deslocamentoX: deslocamentoX, deslocamentoY: deslocamentoY, slideFactor: slideFactor)
        }
        
        //sempre que você soltar essa funcão zera a traslação prévia
        if pan.state == .ended {
            deslocamentoAnteriorX = 0.0
            deslocamentoAnteriorY = 0.0
            
        } else {
            deslocamentoAnteriorX = translacaoX
            deslocamentoAnteriorY = translacaoY
        }
    }

    //apresenta apenas o quadrinho atual (número int passado na func fimDeCena)
    func apresentarQuadrinho(numero:Int) {
        self.addChild(cenasIntro[numero])
    }
    
    //muda cena pro mapa
    func mudarCena() {
        let novaCena = SKScene(fileNamed: "TelaMapa")!
        novaCena.scaleMode = .aspectFill
        let transition = SKTransition.moveIn(with: .right, duration: 0.3)
        self.view?.presentScene(novaCena, transition: transition)
    }
    
    
    override func update(_ currentTime: TimeInterval) {
//        cenasIntro[quadrinhoAtual].position.x = deslocamentoXMax(posicaoAtual: cenasIntro[quadrinhoAtual].position.x)
//        cenasIntro[quadrinhoAtual].position.y = deslocamentoYMax(posicaoAtual: cenasIntro[quadrinhoAtual].position.y)
        
        if quadrinhoAtual == 7 {
            if contagem < 15 {
                if let data = motionManager.accelerometerData {
                    if data.acceleration.x > 0.2 {
                        valorX = data.acceleration.x
                        shake()
                    }
                }
            }
        }
    }

//    func deslocamentoXMax(posicaoAtual: CGFloat) -> CGFloat {
//        let limiteXMod = cenasIntro[quadrinhoAtual].size.width/2.0 - self.size.width / 2.0
//        var novaPosicao:CGFloat
//        if posicaoAtual > limiteXMod {
//            novaPosicao = limiteXMod
//        }
//        else if posicaoAtual < -limiteXMod {
//            novaPosicao = -limiteXMod
//        } else {
//            novaPosicao = posicaoAtual
//        }
//        return novaPosicao
//    }
//
//    func deslocamentoYMax(posicaoAtual: CGFloat) -> CGFloat {
//        let limiteYMod = cenasIntro[quadrinhoAtual].size.height/2.0 - self.size.height / 2.0
//        var novaPosicao:CGFloat
//        if posicaoAtual > limiteYMod {
//            novaPosicao = limiteYMod
//        }
//        else if posicaoAtual < -limiteYMod {
//            novaPosicao = -limiteYMod
//        } else {
//            novaPosicao = posicaoAtual
//        }
//        return novaPosicao
//    }
    
    func shake() {
        print(contagem)
        deslocamento = abs(valorX - anteriorValorX)
        if contagem < 15 {
            contagem += CGFloat(deslocamento)
            manager.carregandoSami(contagem: contagem)
            anteriorValorX = valorX
            
        }
        if contagem > 15 {
            motionManager.stopAccelerometerUpdates()
            manager.fimDoCarregamento()
        }
    }
}

//protocolo adiciona int no quadrinho atual
extension TelaQuadrinho:IntroManager {
    func fimDeCena() {
        self.removeAllChildren()
        if quadrinhoAtual < 10 {
            quadrinhoAtual += 1
            if quadrinhoAtual < cenasIntro.count {
                apresentarQuadrinho(numero: quadrinhoAtual)
            }
        } else {
            mudarCena()
        }
    }
}
