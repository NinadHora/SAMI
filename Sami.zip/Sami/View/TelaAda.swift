//
//  TelaAda.swift
//  Sami
//
//  Created by Mariana MOS on 09/01/19.
//  Copyright © 2019 DaHora. All rights reserved.
//

import Foundation
import SpriteKit

class TelaAda:SKScene {
    
    var manager: ElementosManager!
    var livroAnimado:SKLivroAnimado?
    var fundo: SKFundoTelas!
    var iconeVoltar: SKBotaoVoltar!
    var falasAda: [String]!
    var falaAda: String!
    var contadorFalasAda: Int = 0
    //    var elementoInvisivel:SKReferenciaToque?
    var iconeAvancarPagina: SKIcone!
    var iconeVoltarPagina: SKIcone!
    
    
    
    //mensagens
    var mensagem: SKMensagem?
    
    
    override func didMove(to view: SKView) {
        
        criarElementos()
        
    }
    
    
    
    func criarElementos() {
        fundo = SKFundoTelas(nomeTextura: "BackMesaAda")
        addChild(fundo)
        //        elementoInvisivel = SKReferenciaToque(manager: self,
        //                                              id: "elementoInvisivel",
        //                                              tamanho: CGSize(width: 1334, height: 768),
        //                                              posicao: CGPoint(x: 334, y: 0),
        //                                              z: 10)
        //        addChild(elementoInvisivel!)
        iconeVoltar = SKBotaoVoltar(manager: self, posicao: CGPoint(x: -580, y: 300), z: 10)
        addChild(iconeVoltar)
        let livro = SKLivroAnimado(manager: self, posicao: CGPoint(x: 0, y: 0), z: 8)
        addChild(livro)
        self.livroAnimado = livro
        iconeAvancarPagina = SKIcone(manager: self, posicao: CGPoint(x: 515, y: -300), nomeTextura: "IconeAvancarPagina", id:"iconeAvancarPagina")
        iconeAvancarPagina.isHidden = true
        addChild(iconeAvancarPagina)
        iconeVoltarPagina = SKIcone(manager: self, posicao: CGPoint(x: -515, y: -310), nomeTextura: "IconeVoltarPagina", id:"iconeVoltarPagina")
        iconeVoltarPagina.isHidden = true
        addChild(iconeVoltarPagina)
        
        criarMensagem()
        
        
        
    }
    
    func criarMensagem() {
        
    }
    
}

extension TelaAda: ElementosManager {
    
    func tocouEm(id: String) {
        
        switch id {
        case "LivroAnimado":
            
            if livroAnimado?.livroAberto == false {
                livroAnimado?.animarLivro()
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.iconeAvancarPagina.isHidden = false
            }
            
        case "Voltar":
            if let novaCena = Biblioteca(fileNamed: "Biblioteca"){
                novaCena.scaleMode = .aspectFill
                self.view?.presentScene(novaCena)
            }
        case "iconeVoltarPagina":
            if livroAnimado?.paginaPassada == true {
                livroAnimado?.voltarPaginaDoLivro()
                iconeVoltarPagina.isHidden = true
                iconeAvancarPagina.isHidden = true
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    self.iconeAvancarPagina.isHidden = false
                }
            }
            
        case "iconeAvancarPagina":
            if livroAnimado?.livroAberto == true {
                livroAnimado?.passarPaginaDoLivro()
                iconeAvancarPagina.isHidden = true
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    self.iconeVoltarPagina.isHidden = false
                    self.iconeAvancarPagina.isHidden = false
                }
            }
            if livroAnimado?.paginaPassada == true {
                livroAnimado?.passarPaginaDoLivro2()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                    if let novaCena = TelaPremissa(fileNamed: "TelaPremissa"){
                        novaCena.scaleMode = .aspectFill
                        self.view?.presentScene(novaCena)
                        
                    }
                    
                }
                
            }
            
        default:
            break
        }
        
    }
    
}

