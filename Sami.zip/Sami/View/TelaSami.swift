//
//  TelaSami.swift
//  Sami
//
//  Created by Maria Gorette Soares Tavares on 13/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import Foundation
import SpriteKit

class TelaSami:SKScene {
    
    var iconeVoltar: SKBotaoVoltar!
    var sami: SKSami!
//    var balao: SKBalaoSami!
    var balao: SKBalao!
    var textoBalao: [String] = []
    var contagemBalao: Int = 0
    
    var aurea1:SKNodeNormal!
    var aurea2:SKNodeNormal!
    var luzes:SKNodeNormal!
    var chao:SKNodeNormal!
    var fundo: SKFundoTelas!
    
    let centro:CGPoint = CGPoint(x: 0, y: 0)
    
    override func didMove(to view: SKView) {
        criarElementos()
        
        animarCenario(elemento: aurea1, angulo: 0.7)
        animarCenario(elemento: aurea2, angulo: -1.0)
        animarCenario(elemento: luzes, angulo: 0.4)
        criarBalao(texto: textoBalao[contagemBalao])
    }
    
    func criarElementos () {
        
        iconeVoltar = SKBotaoVoltar(manager: self, posicao: CGPoint(x: -580, y: 300), z: 10)
        addChild(iconeVoltar)
        
        sami = SKSami(manager: self, posicao: CGPoint(x: -50, y: -50), z: 2, nomeTextura: "SamiForma", samiAnimado: true)
        addChild(sami)
        
        //        balao = SKNodeNormal(nomeTextura: "Ada1", posicao: CGPoint(x: 400, y: 0), z: 3)
        //        addChild(balao)
        
        textoBalao = ["Só consigo lembrar de um nome.. Ada Lovelace. Me Ajude a procurar?",
                      "Que tal procurar na biblioteca da cidade?"]
        
        // Fundo
        aurea1 = SKNodeNormal(nomeTextura: "aurea1", posicao: centro, z: -2)
        aurea2 = SKNodeNormal(nomeTextura: "aurea2", posicao: centro, z: -2)
        luzes = SKNodeNormal(nomeTextura: "luzesEscuras", posicao: centro, z: -3)
        chao = SKNodeNormal(nomeTextura: "Chao", posicao: CGPoint(x: 0, y: -380), z: -1)
        fundo = SKFundoTelas(nomeTextura: "BackSami")
        aurea1.setScale(0.8)
        aurea2.setScale(0.8)
        luzes.setScale(0.8)
        chao.setScale(0.8)
        fundo.setScale(0.6)
        addChild(aurea1)
        addChild(aurea2)
        addChild(luzes)
        addChild(chao)
        addChild(fundo)
        
    }
    
    func animarCenario(elemento:SKNodeNormal, angulo: CGFloat) {
        let girar = SKAction.rotate(byAngle: angulo, duration: 1)
        elemento.run(SKAction.repeatForever(girar))
    }
    
    func criarBalao(texto:String) {
//        balao = SKBalaoSami(manager: self, posicao: CGPoint(x: 350, y: 50), z: 3, nomeTextura: "BalaoVirado", texto: texto )
        balao = SKBalao(manager: self, posicao: CGPoint(x: 350, y: 50), z: 3, nomeTextura: "BalaoVirado", texto: textoBalao[contagemBalao], id: "SamiBalao")
        balao.texto.position = CGPoint(x: 20, y: 0)
        addChild(balao)
    }
    
}

extension TelaSami: ElementosManager {
    func tocouEm(id: String) {
        switch id {
        case "Voltar":
            if let novaCena = TelaMapa(fileNamed: "TelaMapa"){
                novaCena.scaleMode = .aspectFill
                self.view?.presentScene(novaCena)
            }
            
        case "SamiBalao":
            contagemBalao += 1
            balao.removeFromParent()
            if contagemBalao >= textoBalao.count {
                contagemBalao = 0
                criarBalao(texto: textoBalao[contagemBalao])
                balao.animarBalao()
            } else if contagemBalao < textoBalao.count {
                criarBalao(texto: textoBalao[contagemBalao])
                balao.animarBalao()
            }
        default:
            print("nao tocou")
        }
    }
}
