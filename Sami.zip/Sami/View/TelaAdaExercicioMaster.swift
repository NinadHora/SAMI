//
//  TelaAdaExercicio.swift
//  Sami
//
//  Created by Mariana MOS on 18/01/19.
//  Copyright © 2019 DaHora. All rights reserved.
//

import Foundation
import SpriteKit

class TelaAdaExercicioMaster: SKScene {
    
    
    override func didMove(to view: SKView) {
        super.didMove(to: SKView.init())
    }
    
}
