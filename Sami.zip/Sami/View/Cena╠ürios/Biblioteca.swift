//
//  Biblioteca.swift
//  Sami
//
//  Created by Maria Gorette Soares Tavares on 11/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import Foundation
import SpriteKit
import GameplayKit

class Biblioteca: SKScene {
    
//    let background = SKSpriteNode(imageNamed: "BackBiblio")
//    let livroAda = SKSpriteNode(imageNamed: "LivroAda")
//
//    override func didMove(to view: SKView) {
//
//        addChild(background)
//        addChild(livroAda)
//    }
    
    var fundo : SKFundoTelas!
    var livroAda : SKIcone!
    var iconeVoltar: SKBotaoVoltar!
    
        override func didMove(to view: SKView) {
            
            criarElementos()
    

        }
    
    func criarElementos (){
        fundo = SKFundoTelas(nomeTextura: "BackBiblio")
        addChild(fundo)
        livroAda = SKIcone(manager: self, posicao: CGPoint(x: 410, y: 130), nomeTextura: "LivroAda", id: "livroAda")
        addChild(livroAda)
        iconeVoltar = SKBotaoVoltar(manager: self, posicao: CGPoint(x: -580, y: 300), z: 10)
        addChild(iconeVoltar)
    }
    
    // puxar elementos: background e Livro
    // posicionar elementos
    
    // função mudar para TelaPremissa
        // quando Livro for tocado
        // mudar para TelaPremissa
    
}

extension Biblioteca: ElementosManager {
    
    
    func tocouEm(id: String) {
        
        switch id {
            
        case "livroAda":
            print("livroAda")
            if let novaCena = TelaPremissa(fileNamed: "TelaAda"){
                novaCena.scaleMode = .aspectFill
//                let transition = SKTransition.moveIn(with: .down, duration: 0.3)
                self.view?.presentScene(novaCena)
            }
        case "Voltar":
            if let novaCena = TelaMapa(fileNamed: "TelaMapa"){
                novaCena.scaleMode = .aspectFill
                self.view?.presentScene(novaCena)
            }
            
        default:
            print("nao tocou")
        }
        
        
    }
    
    
    
}
