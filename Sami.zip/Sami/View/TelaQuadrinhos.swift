//
//  TelaQuadrinhos.swift
//  Sami
//
//  Created by Ana Da hora on 03/12/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

// Bruna e Gorette
import SpriteKit
import GameplayKit

class TelaQuadrinhos: SKScene, UIGestureRecognizerDelegate {
    
    
// tela que irá exibir elementos de cada quadrinho
    
    var menina: SKSpriteNode?


    override public func didMove(to view: SKView){
        
        menina = SKSpriteNode(imageNamed: "")
        menina?.position = CGPoint(x: 270, y: -150)
        menina?.setScale(0.7)
        menina?.zPosition = 10
        menina?.name = ""
        addChild(menina!)
    }


}

